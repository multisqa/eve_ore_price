"use strict";

// =====================================================================
//  EVE - Prix des minerais  ::  logique de l'application
//  Le serveur (serveur.ps1) fournit les donnees ESI et les prix
//  conseilles. Cette page affiche, compare a tes ordres, et alerte.
// =====================================================================

const nf2 = new Intl.NumberFormat("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const nf0 = new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 0 });

const $ = (id) => document.getElementById(id);
const prix = (n) => (n === null || n === undefined ? "—" : nf2.format(n));
const vol  = (n) => (n === null || n === undefined ? "—" : nf0.format(n));

const etat = {
  config: null,
  marche: null,
  ordres: chargerOrdres(),
  recherche: "",
  intervalle: 30,
  minuteur: null,
  battement: null,
  secondes: 0,
  notif: false,
  alertesPrec: 0,
};

// ---------------------------------------------------------------------
//  Mes ordres (memorises dans le navigateur)
// ---------------------------------------------------------------------
function cleOrdre(hub, mineral) { return hub + "||" + mineral; }

function chargerOrdres() {
  try { return JSON.parse(localStorage.getItem("epm_ordres") || "{}"); }
  catch { return {}; }
}
function sauverOrdres() {
  localStorage.setItem("epm_ordres", JSON.stringify(etat.ordres));
}
function ordreDe(hub, mineral) {
  return etat.ordres[cleOrdre(hub, mineral)] || null;
}

// ---------------------------------------------------------------------
//  Appels au serveur local
// ---------------------------------------------------------------------
async function api(chemin, options) {
  const rep = await fetch(chemin, options);
  if (!rep.ok) throw new Error("HTTP " + rep.status + " sur " + chemin);
  const ct = rep.headers.get("content-type") || "";
  return ct.includes("json") ? rep.json() : rep.text();
}

// ---------------------------------------------------------------------
//  Chargement
// ---------------------------------------------------------------------
async function chargerConfig() {
  etat.config = await api("/api/config");
  remplireParams();
  rendreHubs();
  rendreMinerais();
}

async function chargerMarche(force) {
  marquerEtat("chargement", "actualisation…");
  try {
    etat.marche = await api("/api/marche" + (force ? "?force=1" : ""));
    marquerEtat("ok", "ESI connecté");
    rendreTout();
  } catch (e) {
    marquerEtat("err", "erreur ESI");
    $("pied-erreurs").textContent = "Erreur : " + e.message;
    throw e;
  }
  $("maj-heure").textContent = "maj " + etat.marche.maj_lisible;
  relancerCompteARebours();
}

function marquerEtat(classe, texte) {
  $("pastille").className = "pastille " + classe;
  $("etat-texte").textContent = texte;
}

// ---------------------------------------------------------------------
//  Rendu
// ---------------------------------------------------------------------
function rendreTout() {
  rendreTable();
  rendreArbitrage();
  rendreAlertes();
  rendreKpis();
  $("pied-source").textContent =
    "Source : ESI — API publique d'EVE Online (lecture seule). Cache ESI " +
    etat.marche.cache_secondes + " s.";
  $("pied-erreurs").textContent = (etat.marche.erreurs && etat.marche.erreurs.length)
    ? "⚠ " + etat.marche.erreurs.join("  |  ") : "";
}

function lignesFiltrees() {
  if (!etat.marche) return [];
  const q = etat.recherche.trim().toLowerCase();
  return etat.marche.lignes.filter((l) => !q || l.mineral.toLowerCase().includes(q));
}

function rendreTable() {
  const corps = $("corps-marche");
  // Ne pas reconstruire le tableau pendant que l'utilisateur saisit un prix
  // (sinon le champ perd le focus a chaque frappe).
  const actif = document.activeElement;
  if (actif && actif.closest && actif.closest("#table-marche")) return;

  const lignes = lignesFiltrees();
  if (!lignes.length) {
    corps.innerHTML = '<tr><td colspan="12" class="vide">Aucune donnée. Vérifie les minerais et hubs cochés.</td></tr>';
    return;
  }
  corps.innerHTML = lignes.map((l) => ligneHtml(l)).join("");

  corps.querySelectorAll("input.prix-ordre").forEach((inp) => {
    inp.addEventListener("input", () => {
      const hub = inp.dataset.hub, mineral = inp.dataset.mineral;
      const sens = corps.querySelector(
        `.sens-ordre[data-hub="${cssEchappe(hub)}"][data-mineral="${cssEchappe(mineral)}"]`
      ).value;
      const val = parseFloat(inp.value.replace(",", "."));
      if (isNaN(val) || val <= 0) delete etat.ordres[cleOrdre(hub, mineral)];
      else etat.ordres[cleOrdre(hub, mineral)] = { prix: val, sens: sens };
      sauverOrdres();
      const l = etat.marche.lignes.find((x) => x.hub === hub && x.mineral === mineral);
      majCellulesLigne(inp.closest("tr"), l);
      rendreAlertes();
      rendreKpis();
    });
  });
  corps.querySelectorAll("select.sens-ordre").forEach((sel) => {
    sel.addEventListener("change", () => {
      const hub = sel.dataset.hub, mineral = sel.dataset.mineral;
      const entree = etat.ordres[cleOrdre(hub, mineral)];
      if (entree) { entree.sens = sel.value; sauverOrdres(); }
      const l = etat.marche.lignes.find((x) => x.hub === hub && x.mineral === mineral);
      majCellulesLigne(sel.closest("tr"), l);
      rendreAlertes();
      rendreKpis();
    });
  });
  corps.querySelectorAll("button.copier").forEach((b) => {
    b.addEventListener("click", () => copier(b.dataset.prix, b));
  });
}

function cssEchappe(s) { return s.replace(/"/g, '\\"'); }

function ligneHtml(l) {
  const o = ordreDe(l.hub, l.mineral);
  const { classe, texte, nouveau } = evalEtat(l, o);
  const sens = o ? o.sens : "vente";

  const cellAchat = l.achat_max === null
    ? '<span class="tag neutre">—</span>'
    : `${prix(l.achat_max)} <small>${vol(l.achat_volume)}</small>`;
  const cellVente = l.vente_min === null
    ? '<span class="tag neutre">—</span>'
    : `${prix(l.vente_min)} <small>${vol(l.vente_volume)}</small>`;

  const ecart = l.spread === null ? "—"
    : `<span class="${l.spread < 0 ? "tag mauvais" : ""}">${prix(l.spread)}</span>`;

  const cellNouveau = nouveau === null
    ? '<span class="tag neutre">—</span>'
    : `<b class="mono">${prix(nouveau)}</b>`;

  const boutonNouveau = nouveau === null ? "" :
    `<button class="copier" data-prix="${nouveau}" title="Copier ${nouveau}">copier</button>`;

  return `<tr>
    <td>${l.hub}</td>
    <td>${l.mineral}</td>
    <td class="num mono">${cellAchat}</td>
    <td class="num mono">${cellVente}</td>
    <td class="num mono">${ecart}</td>
    <td class="num mono">${prix(l.prix_vente)}</td>
    <td class="num mono">${prix(l.prix_achat)}</td>
    <td class="num mono">${prix(l.net_vente_posee)}</td>
    <td>
      <input class="prix-ordre" type="number" step="0.01" min="0"
             data-hub="${esc(l.hub)}" data-mineral="${esc(l.mineral)}"
             value="${o ? o.prix : ""}" placeholder="—">
      <select class="sens-ordre" data-hub="${esc(l.hub)}" data-mineral="${esc(l.mineral)}">
        <option value="vente"${sens === "vente" ? " selected" : ""}>vente</option>
        <option value="achat"${sens === "achat" ? " selected" : ""}>achat</option>
      </select>
    </td>
    <td data-role="etat"><span class="tag ${classe}">${texte}</span></td>
    <td class="num" data-role="nouveau">${cellNouveau}</td>
    <td data-role="action">${boutonNouveau}</td>
  </tr>`;
}

// Met a jour une seule ligne (etat / nouveau prix / bouton) sans reconstruire
// le tableau : indispensable pour ne pas perdre le focus pendant la saisie.
function majCellulesLigne(tr, l) {
  if (!tr || !l) return;
  const o = ordreDe(l.hub, l.mineral);
  const { classe, texte, nouveau } = evalEtat(l, o);
  const celEtat = tr.querySelector('[data-role="etat"]');
  if (celEtat) celEtat.innerHTML = `<span class="tag ${classe}">${texte}</span>`;
  const celNouveau = tr.querySelector('[data-role="nouveau"]');
  if (celNouveau) celNouveau.innerHTML = nouveau === null
    ? '<span class="tag neutre">—</span>' : `<b class="mono">${prix(nouveau)}</b>`;
  const celAction = tr.querySelector('[data-role="action"]');
  if (celAction) {
    celAction.innerHTML = nouveau === null ? ""
      : `<button class="copier" data-prix="${nouveau}" title="Copier ${nouveau}">copier</button>`;
    const b = celAction.querySelector("button.copier");
    if (b) b.addEventListener("click", () => copier(b.dataset.prix, b));
  }
}

function esc(s) {
  return String(s).replace(/&/g, "&amp;").replace(/"/g, "&quot;")
    .replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// Etat d'un ordre par rapport au marche.
function evalEtat(l, o) {
  if (!o) return { classe: "neutre", texte: "—", nouveau: null };
  if (o.sens === "vente") {
    if (l.vente_min === null) return { classe: "neutre", texte: "pas de vente", nouveau: null };
    if (o.prix <= l.vente_min) return { classe: "bon", texte: "meilleur", nouveau: l.prix_vente };
    return { classe: "mauvais", texte: "dépassé", nouveau: l.prix_vente };
  } else {
    if (l.achat_max === null) return { classe: "neutre", texte: "pas d'achat", nouveau: null };
    if (o.prix >= l.achat_max) return { classe: "bon", texte: "meilleur", nouveau: l.prix_achat };
    return { classe: "mauvais", texte: "dépassé", nouveau: l.prix_achat };
  }
}

// ---------------------------------------------------------------------
//  Arbitrage inter-hubs
// ---------------------------------------------------------------------
function calculerArbitrage() {
  if (!etat.marche) return [];
  const parMineral = {};
  for (const l of etat.marche.lignes) {
    (parMineral[l.mineral] = parMineral[l.mineral] || []).push(l);
  }
  const frais = etat.marche.frais;
  const courtage = frais.courtage_pct / 100, taxe = frais.taxe_vente_pct / 100;
  const res = [];
  for (const [mineral, lignes] of Object.entries(parMineral)) {
    let achat = null, vente = null;
    for (const l of lignes) {
      if (l.vente_min !== null && (!achat || l.vente_min < achat.vente_min)) achat = l;
      if (l.achat_max !== null && (!vente || l.achat_max > vente.achat_max)) vente = l;
    }
    if (!achat || !vente || achat.hub === vente.hub) continue;
    const brut = vente.achat_max - achat.vente_min;
    const net = vente.achat_max * (1 - taxe) - achat.vente_min * (1 + courtage);
    if (brut <= 0) continue;
    res.push({ mineral, achat, vente, brut, net });
  }
  res.sort((a, b) => b.net - a.net);
  return res;
}

function rendreArbitrage() {
  const lignes = calculerArbitrage();
  const corps = $("corps-arbi");
  if (!lignes.length) {
    corps.innerHTML = '<tr><td colspan="7" class="vide">Pas d\'opportunité (il faut au moins 2 hubs suivis).</td></tr>';
    return;
  }
  corps.innerHTML = lignes.map((a) => `<tr>
    <td>${a.mineral}</td>
    <td>${a.achat.hub}</td>
    <td class="num mono">${prix(a.achat.vente_min)}</td>
    <td>${a.vente.hub}</td>
    <td class="num mono">${prix(a.vente.achat_max)}</td>
    <td class="num mono">${prix(a.brut)}</td>
    <td class="num mono" style="color:${a.net > 0 ? "var(--bon)" : "var(--mauvais)"}">${prix(a.net)}</td>
  </tr>`).join("");
}

// ---------------------------------------------------------------------
//  Alertes
// ---------------------------------------------------------------------
function alertes() {
  if (!etat.marche) return [];
  const q = etat.recherche.trim().toLowerCase();
  return etat.marche.lignes
    .filter((l) => !q || l.mineral.toLowerCase().includes(q))
    .map((l) => ({ l, e: evalEtat(l, ordreDe(l.hub, l.mineral)) }))
    .filter((x) => x.e.classe === "mauvais");
}

function rendreAlertes() {
  const a = alertes();
  const bloc = $("bloc-alertes");
  if (!a.length) { bloc.hidden = true; $("liste-alertes").innerHTML = ""; etat.alertesPrec = 0; return; }
  bloc.hidden = false;
  $("liste-alertes").innerHTML = a.map(({ l, e }) => {
    const o = ordreDe(l.hub, l.mineral);
    const sens = o.sens === "vente" ? "vente" : "achat";
    const meilleur = sens === "vente" ? l.vente_min : l.achat_max;
    return `<div class="alerte">
      <b>${l.hub} · ${l.mineral}</b>
      <span>ton ordre ${sens} à <span class="mono">${prix(o.prix)}</span>
            — le carnet est à <span class="mono">${prix(meilleur)}</span></span>
      <span class="fl">
        <span>nouveau prix : <b class="mono">${prix(e.nouveau)}</b></span>
        <button class="copier" data-prix="${e.nouveau}">copier</button>
      </span>
    </div>`;
  }).join("");
  $("liste-alertes").querySelectorAll("button.copier").forEach((b) => {
    b.addEventListener("click", () => copier(b.dataset.prix, b));
  });
  if (etat.notif && a.length > etat.alertesPrec && "Notification" in window) {
    try {
      new Notification("EVE · ordre dépassé", {
        body: a.length + " ordre(s) à reposer — ouvre le tableau pour le nouveau prix.",
      });
    } catch { /* ignore */ }
  }
  etat.alertesPrec = a.length;
}

function rendreKpis() {
  if (!etat.marche) return;
  $("kpi-hubs").textContent = etat.marche.hubs.length;
  $("kpi-minerais").textContent = etat.marche.minerais.length;
  const a = alertes();
  $("kpi-alertes").textContent = a.length;
  const arbi = calculerArbitrage();
  $("kpi-arbi").textContent = arbi.length ? prix(arbi[0].net) : "—";
}

// ---------------------------------------------------------------------
//  Hubs & minerais (puces a cocher)
// ---------------------------------------------------------------------
function rendreHubs() {
  $("liste-hubs").innerHTML = etat.config.hubs.map((h, i) => `
    <label class="puce ${h.actif ? "actif" : ""}">
      <input type="checkbox" data-type="hub" data-index="${i}" ${h.actif ? "checked" : ""}>
      ${h.nom}
    </label>`).join("");
  brancherPuces();
}

function rendreMinerais() {
  $("liste-minerais").innerHTML = etat.config.minerais.map((m, i) => `
    <label class="puce ${m.actif ? "actif" : ""}">
      <input type="checkbox" data-type="minerai" data-index="${i}" ${m.actif ? "checked" : ""}>
      ${m.nom}
    </label>`).join("");
  brancherPuces();
}

function brancherPuces() {
  document.querySelectorAll('.puce input[type="checkbox"]').forEach((c) => {
    c.addEventListener("change", async () => {
      const i = parseInt(c.dataset.index, 10);
      if (c.dataset.type === "hub") etat.config.hubs[i].actif = c.checked;
      else etat.config.minerais[i].actif = c.checked;
      c.closest(".puce").classList.toggle("actif", c.checked);
      await sauverConfig();
      chargerMarche(true).catch(() => {});
    });
  });
}

async function sauverConfig() {
  await api("/api/config", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(etat.config),
  });
}

// ---------------------------------------------------------------------
//  Parametres
// ---------------------------------------------------------------------
function remplireParams() {
  const c = etat.config;
  $("inp-courtage").value = c.frais.courtage_pct;
  $("inp-taxe").value = c.frais.taxe_vente_pct;
  $("inp-volmin").value = c.filtre.volume_min;
  $("inp-pas").value = c.strategie.pas_sous_cote;
  $("sel-comportement").value = c.strategie.comportement;
  $("inp-aberrant").checked = !!c.filtre.ignorer_prix_aberrants;
  $("inp-ecart").value = c.filtre.ecart_aberrant_pct;
  $("inp-cache").value = c.duree_cache_esi_s;
  $("inp-limiter-station").checked = c.limiter_station !== false;
}

async function sauverParams() {
  const c = etat.config;
  c.frais.courtage_pct = num("inp-courtage", 3);
  c.frais.taxe_vente_pct = num("inp-taxe", 8);
  c.filtre.volume_min = Math.max(1, Math.round(num("inp-volmin", 1)));
  c.strategie.pas_sous_cote = Math.max(0.01, num("inp-pas", 0.01));
  c.strategie.comportement = $("sel-comportement").value;
  c.filtre.ignorer_prix_aberrants = $("inp-aberrant").checked;
  c.filtre.ecart_aberrant_pct = Math.min(95, Math.max(5, num("inp-ecart", 60)));
  c.duree_cache_esi_s = Math.max(30, Math.round(num("inp-cache", 300)));
  c.limiter_station = $("inp-limiter-station").checked;
  await sauverConfig();
  $("params-info").textContent = "Enregistré.";
  setTimeout(() => ($("params-info").textContent = ""), 2500);
  chargerMarche(true).catch(() => {});
  remplireParams();
}

function num(id, defaut) {
  const v = parseFloat($(id).value);
  return isNaN(v) ? defaut : v;
}

// ---------------------------------------------------------------------
//  Ajouter un minerai (resolution du type_id via ESI)
// ---------------------------------------------------------------------
async function ajouterMinerai() {
  const nom = $("inp-nouveau-minerai").value.trim();
  if (!nom) return;
  $("ajout-info").textContent = "recherche…";
  try {
    const r = await api("/api/resoudre?nom=" + encodeURIComponent(nom));
    if (etat.config.minerais.some((m) => m.nom.toLowerCase() === r.nom.toLowerCase())) {
      $("ajout-info").textContent = "déjà présent.";
      return;
    }
    etat.config.minerais.push({ nom: r.nom, type_id: r.type_id, actif: true });
    await sauverConfig();
    $("inp-nouveau-minerai").value = "";
    $("ajout-info").textContent = r.nom + " ajouté (type " + r.type_id + ").";
    rendreMinerais();
    chargerMarche(true).catch(() => {});
  } catch (e) {
    $("ajout-info").textContent = "introuvable : " + nom;
  }
}

// ---------------------------------------------------------------------
//  Copie dans le presse-papiers
// ---------------------------------------------------------------------
async function copier(texte, bouton) {
  try {
    await navigator.clipboard.writeText(String(texte));
    if (bouton) {
      const ancien = bouton.textContent;
      bouton.textContent = "copié !";
      setTimeout(() => (bouton.textContent = ancien), 1200);
    }
  } catch { /* presse-papiers refuse */ }
}

// ---------------------------------------------------------------------
//  Minuteur
// ---------------------------------------------------------------------
function relancerCompteARebours() {
  clearInterval(etat.minuteur);
  clearInterval(etat.battement);
  if (!etat.intervalle) { $("compte-a-rebours").textContent = "manuel"; return; }
  etat.secondes = etat.intervalle;
  $("compte-a-rebours").textContent = "dans " + etat.secondes + " s";
  etat.minuteur = setInterval(() => chargerMarche(false).catch(() => {}), etat.intervalle * 1000);
  etat.battement = setInterval(() => {
    etat.secondes = Math.max(0, etat.secondes - 1);
    $("compte-a-rebours").textContent = "dans " + etat.secondes + " s";
  }, 1000);
}

// ---------------------------------------------------------------------
//  Branchements + demarrage
// ---------------------------------------------------------------------
function brancherEvenements() {
  $("btn-actualiser").addEventListener("click", () => chargerMarche(true).catch(() => {}));
  $("btn-params").addEventListener("click", () => {
    $("panneau-params").hidden = !$("panneau-params").hidden;
  });
  $("btn-sauver-params").addEventListener("click", () => sauverParams().catch(() => {}));
  $("sel-intervalle").addEventListener("change", () => {
    etat.intervalle = parseInt($("sel-intervalle").value, 10);
    relancerCompteARebours();
  });
  $("inp-recherche").addEventListener("input", () => {
    etat.recherche = $("inp-recherche").value;
    rendreTout();
  });
  $("btn-ajouter-minerai").addEventListener("click", () => ajouterMinerai());
  $("inp-nouveau-minerai").addEventListener("keydown", (e) => {
    if (e.key === "Enter") ajouterMinerai();
  });
  $("btn-notif").addEventListener("click", async () => {
    if (!("Notification" in window)) return;
    if (Notification.permission !== "granted") await Notification.requestPermission();
    etat.notif = Notification.permission === "granted";
    $("btn-notif").classList.toggle("actif", etat.notif);
    $("btn-notif").textContent = etat.notif ? "🔔 Notifs actives" : "🔔 Notifier";
  });
}

async function demarrer() {
  brancherEvenements();
  try {
    await chargerConfig();
    const iv = String(etat.config.intervalle_sondage_s);
    if ([...$("sel-intervalle").options].some((o) => o.value === iv)) {
      $("sel-intervalle").value = iv;
    }
    etat.intervalle = parseInt($("sel-intervalle").value, 10);
    await chargerMarche(true);
  } catch (e) {
    marquerEtat("err", "démarrage impossible");
  }
}

demarrer();
