"use strict";

// =====================================================================
//  EVE - Prix des minerais  ::  logique de l'application
//  Le serveur (serveur.ps1) fournit les donnees ESI et les prix
//  conseilles. Cette page affiche, compare a tes ordres, et alerte.
// =====================================================================

const nf2 = new Intl.NumberFormat("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const nf0 = new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 0 });

const $ = (id) => document.getElementById(id);
const prix = (n) => (n === null || n === undefined ? "—" : nf2.format(n));
const vol  = (n) => (n === null || n === undefined ? "—" : nf0.format(n));

const etat = {
  config: null,
  marche: null,
  ordres: chargerOrdres(),
  recherche: "",
  intervalle: 30,
  minuteur: null,
  battement: null,
  secondes: 0,
  notif: false,
  alertesPrec: 0,
  historique: null,
  mineralCourbe: null,
  heuresCourbe: 168,
  arHistorique: null,
  arHistoriqueMineral: null,
  arDepart: null,
  arArrivee: null,
  arMineral: null,
  arCharge: false,
};

// ---------------------------------------------------------------------
//  Mes ordres (memorises dans le navigateur)
// ---------------------------------------------------------------------
function cleOrdre(hub, mineral) { return hub + "||" + mineral; }

function chargerOrdres() {
  try { return JSON.parse(localStorage.getItem("epm_ordres") || "{}"); }
  catch { return {}; }
}
function sauverOrdres() {
  localStorage.setItem("epm_ordres", JSON.stringify(etat.ordres));
}
function ordreDe(hub, mineral) {
  return etat.ordres[cleOrdre(hub, mineral)] || null;
}

// ---------------------------------------------------------------------
//  Appels au serveur local
// ---------------------------------------------------------------------
async function api(chemin, options) {
  const rep = await fetch(chemin, options);
  if (!rep.ok) throw new Error("HTTP " + rep.status + " sur " + chemin);
  const ct = rep.headers.get("content-type") || "";
  return ct.includes("json") ? rep.json() : rep.text();
}

// ---------------------------------------------------------------------
//  Chargement
// ---------------------------------------------------------------------
async function chargerConfig() {
  etat.config = await api("/api/config");
  remplireParams();
  rendreHubs();
  rendreMinerais();
}

async function chargerMarche(force) {
  marquerEtat("chargement", "actualisation…");
  try {
    etat.marche = await api("/api/marche" + (force ? "?force=1" : ""));
    marquerEtat("ok", "ESI connecté");
    rendreTout();
  } catch (e) {
    marquerEtat("err", "erreur ESI");
    $("pied-erreurs").textContent = "Erreur : " + e.message;
    throw e;
  }
  $("maj-heure").textContent = "maj " + etat.marche.maj_lisible;
  await chargerHistorique().catch(() => {});
  relancerCompteARebours();
}

function marquerEtat(classe, texte) {
  $("pastille").className = "pastille " + classe;
  $("etat-texte").textContent = texte;
}

// ---------------------------------------------------------------------
//  Rendu
// ---------------------------------------------------------------------
function rendreTout() {
  rendreTable();
  rendreArbitrage();
  rendreAchatRevente();
  rendreAlertes();
  rendreKpis();
  majSelecteurMinerai();
  rendreCourbe();
  $("pied-source").textContent =
    "Source : ESI — API publique d'EVE Online (lecture seule). Cache ESI " +
    etat.marche.cache_secondes + " s.";
  $("pied-erreurs").textContent = (etat.marche.erreurs && etat.marche.erreurs.length)
    ? "⚠ " + etat.marche.erreurs.join("  |  ") : "";
}

function lignesFiltrees() {
  if (!etat.marche) return [];
  const q = etat.recherche.trim().toLowerCase();
  return etat.marche.lignes.filter((l) => !q || l.mineral.toLowerCase().includes(q));
}

function rendreTable() {
  const corps = $("corps-marche");
  // Ne pas reconstruire le tableau pendant que l'utilisateur saisit un prix
  // (sinon le champ perd le focus a chaque frappe).
  const actif = document.activeElement;
  if (actif && actif.closest && actif.closest("#table-marche")) return;

  const lignes = lignesFiltrees();
  if (!lignes.length) {
    corps.innerHTML = '<tr><td colspan="12" class="vide">Aucune donnée. Vérifie les minerais et hubs cochés.</td></tr>';
    return;
  }
  corps.innerHTML = lignes.map((l) => ligneHtml(l)).join("");

  corps.querySelectorAll("input.prix-ordre").forEach((inp) => {
    inp.addEventListener("input", () => {
      const hub = inp.dataset.hub, mineral = inp.dataset.mineral;
      const sens = corps.querySelector(
        `.sens-ordre[data-hub="${cssEchappe(hub)}"][data-mineral="${cssEchappe(mineral)}"]`
      ).value;
      const val = parseFloat(inp.value.replace(",", "."));
      if (isNaN(val) || val <= 0) delete etat.ordres[cleOrdre(hub, mineral)];
      else etat.ordres[cleOrdre(hub, mineral)] = { prix: val, sens: sens };
      sauverOrdres();
      const l = etat.marche.lignes.find((x) => x.hub === hub && x.mineral === mineral);
      majCellulesLigne(inp.closest("tr"), l);
      rendreAlertes();
      rendreKpis();
    });
  });
  corps.querySelectorAll("select.sens-ordre").forEach((sel) => {
    sel.addEventListener("change", () => {
      const hub = sel.dataset.hub, mineral = sel.dataset.mineral;
      const entree = etat.ordres[cleOrdre(hub, mineral)];
      if (entree) { entree.sens = sel.value; sauverOrdres(); }
      const l = etat.marche.lignes.find((x) => x.hub === hub && x.mineral === mineral);
      majCellulesLigne(sel.closest("tr"), l);
      rendreAlertes();
      rendreKpis();
    });
  });
  corps.querySelectorAll("button.copier").forEach((b) => {
    b.addEventListener("click", () => copier(b.dataset.prix, b));
  });
}

function cssEchappe(s) { return s.replace(/"/g, '\\"'); }

function ligneHtml(l) {
  const o = ordreDe(l.hub, l.mineral);
  const { classe, texte, nouveau } = evalEtat(l, o);
  const sens = o ? o.sens : "vente";

  const cellAchat = l.achat_max === null
    ? '<span class="tag neutre">—</span>'
    : `${prix(l.achat_max)} <small>${vol(l.achat_volume)}</small>`;
  const cellVente = l.vente_min === null
    ? '<span class="tag neutre">—</span>'
    : `${prix(l.vente_min)} <small>${vol(l.vente_volume)}</small>`;

  const ecart = l.spread === null ? "—"
    : `<span class="${l.spread < 0 ? "tag mauvais" : ""}">${prix(l.spread)}</span>`;

  const cellNouveau = nouveau === null
    ? '<span class="tag neutre">—</span>'
    : `<b class="mono">${prix(nouveau)}</b>`;

  const boutonNouveau = nouveau === null ? "" :
    `<button class="copier" data-prix="${nouveau}" title="Copier ${nouveau}">copier</button>`;

  return `<tr>
    <td>${l.hub}</td>
    <td>${l.mineral}</td>
    <td class="num mono">${cellAchat}</td>
    <td class="num mono">${cellVente}</td>
    <td class="num mono">${ecart}</td>
    <td class="num mono">${prix(l.prix_vente)}</td>
    <td class="num mono">${prix(l.prix_achat)}</td>
    <td class="num mono">${prix(l.net_vente_posee)}</td>
    <td>
      <input class="prix-ordre" type="number" step="0.01" min="0"
             data-hub="${esc(l.hub)}" data-mineral="${esc(l.mineral)}"
             value="${o ? o.prix : ""}" placeholder="—">
      <select class="sens-ordre" data-hub="${esc(l.hub)}" data-mineral="${esc(l.mineral)}">
        <option value="vente"${sens === "vente" ? " selected" : ""}>vente</option>
        <option value="achat"${sens === "achat" ? " selected" : ""}>achat</option>
      </select>
    </td>
    <td data-role="etat"><span class="tag ${classe}">${texte}</span></td>
    <td class="num" data-role="nouveau">${cellNouveau}</td>
    <td data-role="action">${boutonNouveau}</td>
  </tr>`;
}

// Met a jour une seule ligne (etat / nouveau prix / bouton) sans reconstruire
// le tableau : indispensable pour ne pas perdre le focus pendant la saisie.
function majCellulesLigne(tr, l) {
  if (!tr || !l) return;
  const o = ordreDe(l.hub, l.mineral);
  const { classe, texte, nouveau } = evalEtat(l, o);
  const celEtat = tr.querySelector('[data-role="etat"]');
  if (celEtat) celEtat.innerHTML = `<span class="tag ${classe}">${texte}</span>`;
  const celNouveau = tr.querySelector('[data-role="nouveau"]');
  if (celNouveau) celNouveau.innerHTML = nouveau === null
    ? '<span class="tag neutre">—</span>' : `<b class="mono">${prix(nouveau)}</b>`;
  const celAction = tr.querySelector('[data-role="action"]');
  if (celAction) {
    celAction.innerHTML = nouveau === null ? ""
      : `<button class="copier" data-prix="${nouveau}" title="Copier ${nouveau}">copier</button>`;
    const b = celAction.querySelector("button.copier");
    if (b) b.addEventListener("click", () => copier(b.dataset.prix, b));
  }
}

function esc(s) {
  return String(s).replace(/&/g, "&amp;").replace(/"/g, "&quot;")
    .replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// Etat d'un ordre par rapport au marche.
function evalEtat(l, o) {
  if (!o) return { classe: "neutre", texte: "—", nouveau: null };
  if (o.sens === "vente") {
    if (l.vente_min === null) return { classe: "neutre", texte: "pas de vente", nouveau: null };
    if (o.prix <= l.vente_min) return { classe: "bon", texte: "meilleur", nouveau: l.prix_vente };
    return { classe: "mauvais", texte: "dépassé", nouveau: l.prix_vente };
  } else {
    if (l.achat_max === null) return { classe: "neutre", texte: "pas d'achat", nouveau: null };
    if (o.prix >= l.achat_max) return { classe: "bon", texte: "meilleur", nouveau: l.prix_achat };
    return { classe: "mauvais", texte: "dépassé", nouveau: l.prix_achat };
  }
}

// ---------------------------------------------------------------------
//  Arbitrage inter-hubs
// ---------------------------------------------------------------------
function calculerArbitrage() {
  if (!etat.marche) return [];
  const parMineral = {};
  for (const l of etat.marche.lignes) {
    (parMineral[l.mineral] = parMineral[l.mineral] || []).push(l);
  }
  const frais = etat.marche.frais;
  const courtage = frais.courtage_pct / 100, taxe = frais.taxe_vente_pct / 100;
  const res = [];
  for (const [mineral, lignes] of Object.entries(parMineral)) {
    let achat = null, vente = null;
    for (const l of lignes) {
      if (l.vente_min !== null && (!achat || l.vente_min < achat.vente_min)) achat = l;
      if (l.achat_max !== null && (!vente || l.achat_max > vente.achat_max)) vente = l;
    }
    if (!achat || !vente || achat.hub === vente.hub) continue;
    const brut = vente.achat_max - achat.vente_min;
    const net = vente.achat_max * (1 - taxe) - achat.vente_min * (1 + courtage);
    if (brut <= 0) continue;
    res.push({ mineral, achat, vente, brut, net });
  }
  res.sort((a, b) => b.net - a.net);
  return res;
}

function rendreArbitrage() {
  const lignes = calculerArbitrage();
  const corps = $("corps-arbi");
  if (!lignes.length) {
    corps.innerHTML = '<tr><td colspan="7" class="vide">Pas d\'opportunité (il faut au moins 2 hubs suivis).</td></tr>';
    return;
  }
  corps.innerHTML = lignes.map((a) => `<tr>
    <td>${a.mineral}</td>
    <td>${a.achat.hub}</td>
    <td class="num mono">${prix(a.achat.vente_min)}</td>
    <td>${a.vente.hub}</td>
    <td class="num mono">${prix(a.vente.achat_max)}</td>
    <td class="num mono">${prix(a.brut)}</td>
    <td class="num mono" style="color:${a.net > 0 ? "var(--bon)" : "var(--mauvais)"}">${prix(a.net)}</td>
  </tr>`).join("");
}

// ---------------------------------------------------------------------
//  Achat-revente : simulateur avec estimation du prix a l'arrivee.
//  On achete a une station (au prix de vente), on revend a une autre
//  apres un temps de trajet donne, au prix estime par prolongement de
//  la tendance de l'historique accumule (un point par heure et station).
// ---------------------------------------------------------------------
function remplirSelect(sel, valeurs, choix) {
  if (!sel) return;
  const identique = sel.options.length === valeurs.length &&
    [...sel.options].every((o, i) => o.value === valeurs[i]);
  if (!identique) sel.innerHTML = valeurs.map((v) => `<option value="${esc(v)}">${esc(v)}</option>`).join("");
  if (choix && valeurs.includes(choix)) sel.value = choix;
}

function majSelecteursAR() {
  if (!etat.marche) return;
  const hubs = etat.marche.hubs.map((h) => h.nom);
  const minerais = etat.marche.minerais.map((m) => m.nom);
  if (!hubs.length || !minerais.length) return;
  if (!etat.arDepart || !hubs.includes(etat.arDepart)) etat.arDepart = hubs[0];
  if (!etat.arArrivee || !hubs.includes(etat.arArrivee)) etat.arArrivee = hubs.find((h) => h !== etat.arDepart) || hubs[0];
  if (!etat.arMineral || !minerais.includes(etat.arMineral)) etat.arMineral = minerais[0];
  remplirSelect($("sel-ar-depart"), hubs, etat.arDepart);
  remplirSelect($("sel-ar-arrivee"), hubs, etat.arArrivee);
  remplirSelect($("sel-ar-minerai"), minerais, etat.arMineral);
}

// Regression lineaire y = a + b*x sur une liste de points {x, y}.
function regressionLineaire(pts) {
  const n = pts.length;
  if (n < 2) return null;
  let sx = 0, sy = 0, sxx = 0, sxy = 0;
  for (const p of pts) { sx += p.x; sy += p.y; sxx += p.x * p.x; sxy += p.x * p.y; }
  const denom = n * sxx - sx * sx;
  if (denom === 0) return { pente: 0, ordonnee: sy / n, r2: 0, ecart: 0, n };
  const pente = (n * sxy - sx * sy) / denom;
  const ordonnee = (sy - pente * sx) / n;
  const my = sy / n;
  let ssTot = 0, ssRes = 0;
  for (const p of pts) {
    ssTot += (p.y - my) * (p.y - my);
    const f = ordonnee + pente * p.x;
    ssRes += (p.y - f) * (p.y - f);
  }
  const r2 = ssTot > 0 ? 1 - ssRes / ssTot : 0;
  const ecart = n > 2 ? Math.sqrt(ssRes / (n - 2)) : 0;
  return { pente, ordonnee, r2, ecart, n };
}

// Estime le prix de vente a l'arrivee pour un hub, en prolongeant la
// tendance des (jusqu'a) 72 derniers points vers l'heure d'arrivee.
function estimerArrivee(series, hub, heuresTrajet) {
  const s = (series || []).find((x) => x.hub === hub);
  if (!s || !s.points || !s.points.length) return null;

  const brut = s.points
    .map((p) => ({ t: Date.parse(p.t), vm: p.vm, pm: p.pm }))
    .filter((p) => !isNaN(p.t) && p.t > 0)
    .sort((a, b) => a.t - b.t);
  if (!brut.length) return null;

  // On previlegie la meilleure vente (vm) ; si trop rare, la moyenne (pm).
  const nbVM = brut.filter((p) => p.vm != null && p.vm > 0).length;
  const source = nbVM >= 3 ? "vm" : "pm";
  const valeur = (p) => {
    const v = source === "vm" ? p.vm : (p.pm != null ? p.pm : p.vm);
    return (v != null && isFinite(v) && v > 0) ? v : null;
  };
  const pts0 = brut.filter((p) => valeur(p) != null);
  if (!pts0.length) return null;

  const fenetre = pts0.slice(Math.max(0, pts0.length - 72));
  const t0 = fenetre[0].t;
  const pts = fenetre.map((p) => ({ x: (p.t - t0) / 3600000, y: valeur(p) }));
  const reg = regressionLineaire(pts);

  const dernier = pts0[pts0.length - 1];
  const dernierV = valeur(dernier);
  const hDepuis = (dernier.t - t0) / 3600000;
  const spanHeures = (fenetre[fenetre.length - 1].t - t0) / 3600000;
  const vminW = Math.min(...pts.map((p) => p.y));
  const vmaxW = Math.max(...pts.map((p) => p.y));

  let estime = dernierV, pente = 0, r2 = 0, ecart = 0;
  if (reg) {
    pente = reg.pente; r2 = reg.r2; ecart = reg.ecart;
    estime = reg.ordonnee + reg.pente * (hDepuis + heuresTrajet);
  }
  // Si on projette au-dela de l'historique observe, une droite lointaine n'a
  // plus de sens : on borne alors l'estimation a la plage des valeurs vues.
  const horsPortee = heuresTrajet > spanHeures + 0.5;
  if (horsPortee) estime = Math.min(Math.max(estime, vminW), vmaxW);
  if (!(estime > 0)) estime = dernierV;

  const ageHeures = (Date.now() - dernier.t) / 3600000;
  return {
    estime, pente, r2, ecart, n: pts0.length, source, dernierV, ageHeures, horsPortee,
    points: fenetre.map((p) => ({ t: p.t, v: valeur(p) })),
  };
}

function fiabiliteAR(est) {
  if (!est) return { niveau: "aucune", texte: "aucune donnée historique" };
  if (est.n < 3) return { niveau: "faible", texte: "faible (seulement " + est.n + " relevé" + (est.n > 1 ? "s" : "") + ")" };
  if (est.horsPortee) return { niveau: "faible", texte: "faible (horizon plus long que l'historique : estimation bornée)" };
  if (est.ageHeures > 6) return { niveau: "faible", texte: "faible (dernier relevé il y a " + Math.round(est.ageHeures) + " h)" };
  const r2 = est.r2;
  if (r2 < 0.2) return { niveau: "faible", texte: "faible (tendance peu nette, R² " + r2.toFixed(2).replace(".", ",") + ")" };
  if (r2 < 0.5) return { niveau: "moyenne", texte: "moyenne (R² " + r2.toFixed(2).replace(".", ",") + ")" };
  return { niveau: "bonne", texte: "bonne (R² " + r2.toFixed(2).replace(".", ",") + ")" };
}

function dureeTexte(h) {
  if (!(h > 0)) return "immédiat";
  const hh = Math.floor(h);
  const mm = Math.round((h - hh) * 60);
  const parties = [];
  if (hh) parties.push(hh + " h");
  if (mm) parties.push(mm + " min");
  return parties.join(" ") || "immédiat";
}

// Petite courbe : historique (trait plein) + prolongement estime (pointille).
function miniCourbeAR(points, projetT, projetV) {
  if (!points || !points.length) return "";
  const tmin = points[0].t;
  const tmax = Math.max(points[points.length - 1].t, projetT || 0);
  const vals = points.map((p) => p.v);
  if (projetV != null) vals.push(projetV);
  let vmin = Math.min(...vals), vmax = Math.max(...vals);
  if (!(vmax > vmin)) { vmax = vmin * 1.05 + 0.01; vmin = Math.max(0, vmin * 0.95); }
  const W = 560, H = 130, padL = 8, padR = 10, padT = 14, padB = 14;
  const span = (tmax - tmin) || 1;
  const X = (t) => padL + (t - tmin) / span * (W - padL - padR);
  const Y = (v) => H - padB - (v - vmin) / (vmax - vmin) * (H - padT - padB);

  const d = "M" + points.map((p) => X(p.t).toFixed(1) + " " + Y(p.v).toFixed(1)).join(" L");
  let svg = `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">`;
  svg += `<path d="${d}" fill="none" stroke="#46b3a0" stroke-width="2" stroke-linejoin="round"/>`;
  const dernier = points[points.length - 1];
  if (projetT != null && projetV != null) {
    svg += `<path d="M${X(dernier.t).toFixed(1)} ${Y(dernier.v).toFixed(1)} L${X(projetT).toFixed(1)} ${Y(projetV).toFixed(1)}" fill="none" stroke="#d9b45b" stroke-width="2" stroke-dasharray="5 4"/>`;
    svg += `<circle cx="${X(projetT).toFixed(1)}" cy="${Y(projetV).toFixed(1)}" r="3.5" fill="#d9b45b"/>`;
  }
  svg += `<circle cx="${X(dernier.t).toFixed(1)}" cy="${Y(dernier.v).toFixed(1)}" r="3" fill="#6fd6c3"/>`;
  svg += "</svg>";
  return svg;
}

function rendreAchatRevente() {
  if (!etat.marche || !$("ar-resultat")) return;
  majSelecteursAR();
  majAR(false).catch(() => {});
}

async function majAR(force) {
  if (!etat.marche || !etat.arMineral) return;
  if (force || !etat.arHistorique || etat.arHistoriqueMineral !== etat.arMineral) {
    etat.arCharge = true;
    try {
      etat.arHistorique = await api("/api/historique?mineral=" + encodeURIComponent(etat.arMineral) + "&heures=0");
      etat.arHistoriqueMineral = etat.arMineral;
    } catch { etat.arHistorique = null; }
    etat.arCharge = false;
  }
  rendreAR();
}

function rendreAR() {
  const zone = $("ar-resultat");
  if (!zone || !etat.marche) return;
  const depart = etat.arDepart, arrivee = etat.arArrivee, mineral = etat.arMineral;

  if (!depart || !arrivee || !mineral) {
    zone.innerHTML = '<p class="vide">Choisis une station de départ, une station d\'arrivée et un minerai.</p>';
    return;
  }
  if (etat.arCharge && !etat.arHistorique) {
    zone.innerHTML = '<p class="vide">Chargement de l\'historique…</p>';
    return;
  }

  const h = parseFloat($("inp-ar-heures").value) || 0;
  const mn = parseFloat($("inp-ar-min").value) || 0;
  const trajet = Math.max(0, h + mn / 60);

  const lignes = etat.marche.lignes;
  const lDep = lignes.find((l) => l.hub === depart && l.mineral === mineral) || null;
  const lArr = lignes.find((l) => l.hub === arrivee && l.mineral === mineral) || null;

  const frais = etat.marche.frais || { courtage_pct: 3, taxe_vente_pct: 8 };
  const courtage = frais.courtage_pct / 100, taxe = frais.taxe_vente_pct / 100;
  const pas = (etat.marche.strategie && etat.marche.strategie.pas_sous_cote) || 0.01;

  const coutAchat = lDep && lDep.vente_min != null ? lDep.vente_min : null;
  const venteActuelle = lArr && lArr.vente_min != null ? lArr.vente_min : null;

  const est = estimerArrivee(etat.arHistorique && etat.arHistorique.series, arrivee, trajet);
  const fiab = fiabiliteAR(est);
  const prixArrivee = est ? est.estime : venteActuelle;
  const source = est ? "estimation" : (venteActuelle != null ? "prix actuel (aucun historique)" : null);

  const prixConseille = prixArrivee != null ? Math.max(0.01, Math.round((prixArrivee - pas) * 100) / 100) : null;
  const netUnitaire = prixConseille != null ? Math.round(prixConseille * (1 - taxe - courtage) * 100) / 100 : null;
  const margeBrute = (prixArrivee != null && coutAchat != null) ? Math.round((prixArrivee - coutAchat) * 100) / 100 : null;
  const margeNette = (netUnitaire != null && coutAchat != null) ? Math.round((netUnitaire - coutAchat) * 100) / 100 : null;
  const rendement = (margeNette != null && coutAchat) ? margeNette / coutAchat : null;
  const volumeDispo = lDep ? lDep.vente_volume : null;
  const profitTotal = (margeNette != null && volumeDispo != null) ? margeNette * volumeDispo : null;

  const clsMarge = margeNette == null ? "neutre" : (margeNette > 0 ? "bon" : "mauvais");
  let verdict;
  if (margeNette == null) verdict = "Données insuffisantes pour conclure (prix d'achat ou estimation manquants).";
  else if (margeNette > 0) verdict = `Rentable : +${prix(margeNette)} ISK / unité après frais.`;
  else verdict = `Non rentable : ${prix(margeNette)} ISK / unité après frais.`;

  const box = (lab, val, sub, cls) =>
    `<div class="ar-box"><div class="lab">${lab}</div>` +
    `<div class="val ${cls || ""}">${val}</div>` +
    `<div class="sub">${sub || ""}</div></div>`;

  let html = '<div class="ar-carte">';
  html += `<div class="ar-verdict"><span class="ar-marge ${clsMarge}">${verdict}</span>` +
    `<span class="ar-fiab">Fiabilité de l'estimation : <b>${fiab.texte}</b></span></div>`;

  html += '<div class="ar-grille">';
  html += box(`Achat · ${esc(depart)}`, prix(coutAchat),
    coutAchat != null ? `vente min · dispo ${vol(volumeDispo)} u.` : "aucun ordre de vente", "");
  html += box(`Vente · ${esc(arrivee)}`, prix(prixArrivee),
    combiner([source, `dans ${dureeTexte(trajet)}`, venteActuelle != null ? `actuel ${prix(venteActuelle)}` : null]), "");
  html += box("Marge nette / u.", prix(margeNette),
    margeBrute != null ? `brute ${prix(margeBrute)}` : "", clsMarge === "bon" ? "pos" : clsMarge === "mauvais" ? "neg" : "");
  html += box("Rendement", rendement != null ? (rendement * 100).toFixed(1).replace(".", ",") + " %" : "—", "net / achat", "");
  html += box("Prix de vente conseillé", prix(prixConseille), `estimation − ${nf2.format(pas)} ISK`, "");
  html += box("Profit net estimé", prix(profitTotal),
    volumeDispo != null ? `si ${vol(volumeDispo)} u. écoulées` : "", "");
  html += "</div>";

  if (est) {
    html += `<div class="ar-tendance">Tendance sur ${est.n} relevés (${est.source === "vm" ? "meilleure vente" : "moyenne du carnet"}) : ` +
      `${est.pente >= 0 ? "+" : ""}${nf2.format(est.pente)} ISK/h · dernier relevé ${prix(est.dernierV)} il y a ${Math.round(est.ageHeures)} h` +
      (est.ecart ? ` · dispersion ± ${prix(est.ecart)}` : "") + ".</div>";
    if (est.points.length) {
      const pT = est.points[est.points.length - 1].t + trajet * 3600000;
      html += `<div class="ar-courbe">${miniCourbeAR(est.points, pT, est.estime)}</div>`;
      html += '<div class="legende-courbe">' +
        '<span class="leg-item"><i style="background:#46b3a0"></i>historique (vente min)</span>' +
        '<span class="leg-item"><i style="background:#d9b45b"></i>prolongement estimé à l\'arrivée</span></div>';
    }
  } else {
    html += `<p class="note">Aucun historique pour <b>${esc(arrivee)}</b> sur <b>${esc(mineral)}</b> : ` +
      "l'estimation retombe sur le prix de vente actuel. Laisse l'application tourner un moment sur cette station pour accumuler des points.</p>";
  }
  html += "</div>";
  zone.innerHTML = html;
}

function combiner(parties) {
  return parties.filter((x) => x != null && x !== "").join(" · ");
}

// ---------------------------------------------------------------------
//  Courbe du prix de vente moyen dans le temps
//  Le serveur enregistre un point par heure et par station (hub x minerai).
//  On trace, pour le minerai choisi, une courbe par station : trait plein =
//  moyenne du carnet, trait pointille = meilleure vente.
// ---------------------------------------------------------------------
const COULEURS_COURBE = ["#46b3a0", "#d9b45b", "#6fa8dc", "#e0895a", "#b47fe0", "#7fd66f", "#e06f9a", "#c0c8d0"];

async function chargerHistorique() {
  if (!etat.mineralCourbe) { etat.historique = null; rendreCourbe(); return; }
  const url = "/api/historique?mineral=" + encodeURIComponent(etat.mineralCourbe) +
              "&heures=" + etat.heuresCourbe;
  etat.historique = await api(url);
  rendreCourbe();
}

function majSelecteurMinerai() {
  const sel = $("sel-courbe-minerai");
  if (!sel) return;
  const noms = etat.marche ? etat.marche.minerais.map((m) => m.nom) : [];
  if (!noms.length) return;
  if (!etat.mineralCourbe || !noms.includes(etat.mineralCourbe)) etat.mineralCourbe = noms[0];
  const actuels = [...sel.options].map((o) => o.value);
  const identique = actuels.length === noms.length && actuels.every((v, i) => v === noms[i]);
  if (!identique) sel.innerHTML = noms.map((n) => `<option value="${esc(n)}">${esc(n)}</option>`).join("");
  sel.value = etat.mineralCourbe;
}

// Abrege les grands nombres (ISK) pour les etiquettes de l'axe vertical.
function prixAxe(v) {
  const a = Math.abs(v);
  if (a >= 1e9) return (v / 1e9).toFixed(2).replace(".", ",") + " G";
  if (a >= 1e6) return (v / 1e6).toFixed(2).replace(".", ",") + " M";
  if (a >= 1e3) return (v / 1e3).toFixed(1).replace(".", ",") + " k";
  return nf0.format(v);
}

function labelTemps(d, span) {
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  const jj = String(d.getDate()).padStart(2, "0");
  const mo = String(d.getMonth() + 1).padStart(2, "0");
  if (span <= 48 * 3600000) return hh + ":" + mm;
  return jj + "/" + mo + " " + hh + "h";
}

function traceSerie(pts, col, pointille) {
  if (!pts.length) return "";
  const d = "M" + pts.map(([px, py]) => px.toFixed(1) + " " + py.toFixed(1)).join(" L");
  const dash = pointille ? ' stroke-dasharray="5 4" opacity="0.78"' : "";
  let out = `<path d="${d}" fill="none" stroke="${col}" stroke-width="2" stroke-linejoin="round"${dash}/>`;
  if (pts.length === 1) out += `<circle cx="${pts[0][0].toFixed(1)}" cy="${pts[0][1].toFixed(1)}" r="2.6" fill="${col}"/>`;
  return out;
}

function rendreCourbe() {
  const zone = $("courbe-svg");
  const leg = $("legende-courbe");
  const info = $("courbe-info");
  if (!zone) return;
  if (info) { info.style.display = "none"; info.innerHTML = ""; }

  const histo = etat.historique;
  const series = (histo && histo.series ? histo.series : []).filter((s) => s.points && s.points.length);
  if (!series.length) {
    zone.innerHTML = '<p class="vide">Pas encore de données pour ce minerai. La courbe se ' +
      "remplit au fil des heures (un point par heure), tant que l'application tourne.</p>";
    if (leg) leg.innerHTML = "";
    return;
  }

  let tmin = Infinity, tmax = -Infinity, vmin = Infinity, vmax = -Infinity;
  for (const s of series) {
    for (const p of s.points) {
      const t = Date.parse(p.t);
      if (!isNaN(t)) { if (t < tmin) tmin = t; if (t > tmax) tmax = t; }
      for (const v of [p.pm, p.vm]) {
        if (v != null && isFinite(v) && v > 0) { if (v < vmin) vmin = v; if (v > vmax) vmax = v; }
      }
    }
  }
  if (!isFinite(tmin) || !isFinite(vmin)) {
    zone.innerHTML = '<p class="vide">Pas de prix de vente exploitable dans cette période.</p>';
    if (leg) leg.innerHTML = "";
    return;
  }
  if (tmax <= tmin) tmax = tmin + 3600000;
  let marges = (vmax - vmin) * 0.08;
  if (marges <= 0) marges = Math.max(vmax * 0.05, 0.01);
  let vlo = vmin - marges, vhi = vmax + marges;
  if (vlo < 0) vlo = 0;

  const W = 1000, H = 340, padL = 66, padR = 16, padT = 16, padB = 32;
  const span = tmax - tmin;
  const X = (t) => padL + (t - tmin) / span * (W - padL - padR);
  const Y = (v) => H - padB - (v - vlo) / (vhi - vlo) * (H - padT - padB);

  let svg = `<svg viewBox="0 0 ${W} ${H}" class="graphique">`;
  const ny = 4;
  for (let i = 0; i <= ny; i++) {
    const v = vlo + (vhi - vlo) * i / ny;
    const yy = Y(v);
    svg += `<line x1="${padL}" y1="${yy.toFixed(1)}" x2="${W - padR}" y2="${yy.toFixed(1)}" class="grille"/>`;
    svg += `<text x="${padL - 8}" y="${(yy + 4).toFixed(1)}" class="axe axe-y" text-anchor="end">${prixAxe(v)}</text>`;
  }
  const nx = 5;
  for (let i = 0; i <= nx; i++) {
    const t = tmin + span * i / nx;
    const xx = X(t);
    svg += `<line x1="${xx.toFixed(1)}" y1="${padT}" x2="${xx.toFixed(1)}" y2="${H - padB}" class="grille grille-v"/>`;
    svg += `<text x="${xx.toFixed(1)}" y="${H - padB + 18}" class="axe" text-anchor="middle">${labelTemps(new Date(t), span)}</text>`;
  }

  const legende = [];
  series.forEach((s, i) => {
    const col = COULEURS_COURBE[i % COULEURS_COURBE.length];
    legende.push({ hub: s.hub, couleur: col });
    const ptsPM = [], ptsVM = [];
    for (const p of s.points) {
      const t = Date.parse(p.t); if (isNaN(t)) continue;
      if (p.pm != null) ptsPM.push([X(t), Y(p.pm)]);
      if (p.vm != null && p.vm > 0) ptsVM.push([X(t), Y(p.vm)]);
    }
    svg += traceSerie(ptsVM, col, true);
    svg += traceSerie(ptsPM, col, false);
  });
  svg += `<line id="curseur" x1="0" y1="${padT}" x2="0" y2="${H - padB}" class="curseur" style="display:none"/>`;
  svg += "</svg>";
  zone.innerHTML = svg;

  if (leg) {
    leg.innerHTML =
      legende.map((l) => `<span class="leg-item"><i style="background:${l.couleur}"></i>${esc(l.hub)}</span>`).join("") +
      `<span class="leg-item"><svg width="26" height="8"><line x1="1" y1="4" x2="25" y2="4" stroke="#8296ab" stroke-width="2"/></svg>moyenne du carnet</span>` +
      `<span class="leg-item"><svg width="26" height="8"><line x1="1" y1="4" x2="25" y2="4" stroke="#8296ab" stroke-width="2" stroke-dasharray="5 4"/></svg>meilleure vente</span>`;
  }

  // Survol : ligne verticale + infobulle des valeurs a l'heure la plus proche.
  const svgEl = zone.querySelector("svg");
  const curseur = zone.querySelector("#curseur");
  const tousTemps = [...new Set(series.flatMap((s) => s.points.map((p) => p.t)))]
    .map((t) => Date.parse(t)).filter((t) => !isNaN(t)).sort((a, b) => a - b);
  if (!tousTemps.length || !info) return;

  svgEl.addEventListener("mousemove", (ev) => {
    const rect = svgEl.getBoundingClientRect();
    const px = (ev.clientX - rect.left) / rect.width * W;
    let meilleur = tousTemps[0], bd = Infinity;
    for (const t of tousTemps) { const d = Math.abs(X(t) - px); if (d < bd) { bd = d; meilleur = t; } }
    curseur.setAttribute("x1", X(meilleur).toFixed(1));
    curseur.setAttribute("x2", X(meilleur).toFixed(1));
    curseur.style.display = "";

    let html = `<b>${labelTemps(new Date(meilleur), span)}</b>`;
    series.forEach((s, i) => {
      const p = s.points.find((x) => Date.parse(x.t) === meilleur);
      if (!p) return;
      const col = COULEURS_COURBE[i % COULEURS_COURBE.length];
      html += `<div class="tt-ligne"><i style="background:${col}"></i>${esc(s.hub)}` +
        `<span class="mono">${prix(p.pm)} <small>moy</small> · ${prix(p.vm)} <small>min</small></span></div>`;
    });
    info.innerHTML = html;
    info.style.display = "";
    const left = X(meilleur) / W * rect.width;
    info.style.left = Math.min(Math.max(left, 90), Math.max(rect.width - 90, 90)) + "px";
    info.style.top = "10px";
  });
  svgEl.addEventListener("mouseleave", () => {
    curseur.style.display = "none";
    info.style.display = "none";
  });
}

// ---------------------------------------------------------------------
//  Alertes
// ---------------------------------------------------------------------
function alertes() {
  if (!etat.marche) return [];
  const q = etat.recherche.trim().toLowerCase();
  return etat.marche.lignes
    .filter((l) => !q || l.mineral.toLowerCase().includes(q))
    .map((l) => ({ l, e: evalEtat(l, ordreDe(l.hub, l.mineral)) }))
    .filter((x) => x.e.classe === "mauvais");
}

function rendreAlertes() {
  const a = alertes();
  const bloc = $("bloc-alertes");
  if (!a.length) { bloc.hidden = true; $("liste-alertes").innerHTML = ""; etat.alertesPrec = 0; return; }
  bloc.hidden = false;
  $("liste-alertes").innerHTML = a.map(({ l, e }) => {
    const o = ordreDe(l.hub, l.mineral);
    const sens = o.sens === "vente" ? "vente" : "achat";
    const meilleur = sens === "vente" ? l.vente_min : l.achat_max;
    return `<div class="alerte">
      <b>${l.hub} · ${l.mineral}</b>
      <span>ton ordre ${sens} à <span class="mono">${prix(o.prix)}</span>
            — le carnet est à <span class="mono">${prix(meilleur)}</span></span>
      <span class="fl">
        <span>nouveau prix : <b class="mono">${prix(e.nouveau)}</b></span>
        <button class="copier" data-prix="${e.nouveau}">copier</button>
      </span>
    </div>`;
  }).join("");
  $("liste-alertes").querySelectorAll("button.copier").forEach((b) => {
    b.addEventListener("click", () => copier(b.dataset.prix, b));
  });
  if (etat.notif && a.length > etat.alertesPrec && "Notification" in window) {
    try {
      new Notification("EVE · ordre dépassé", {
        body: a.length + " ordre(s) à reposer — ouvre le tableau pour le nouveau prix.",
      });
    } catch { /* ignore */ }
  }
  etat.alertesPrec = a.length;
}

function rendreKpis() {
  if (!etat.marche) return;
  $("kpi-hubs").textContent = etat.marche.hubs.length;
  $("kpi-minerais").textContent = etat.marche.minerais.length;
  const a = alertes();
  $("kpi-alertes").textContent = a.length;
  const arbi = calculerArbitrage();
  $("kpi-arbi").textContent = arbi.length ? prix(arbi[0].net) : "—";
}

// ---------------------------------------------------------------------
//  Hubs & minerais (puces a cocher)
// ---------------------------------------------------------------------
function rendreHubs() {
  $("liste-hubs").innerHTML = etat.config.hubs.map((h, i) => `
    <label class="puce ${h.actif ? "actif" : ""}">
      <input type="checkbox" data-type="hub" data-index="${i}" ${h.actif ? "checked" : ""}>
      ${h.nom}
    </label>`).join("");
  brancherPuces();
}

function rendreMinerais() {
  $("liste-minerais").innerHTML = etat.config.minerais.map((m, i) => `
    <label class="puce ${m.actif ? "actif" : ""}">
      <input type="checkbox" data-type="minerai" data-index="${i}" ${m.actif ? "checked" : ""}>
      ${m.nom}
    </label>`).join("");
  brancherPuces();
}

function brancherPuces() {
  document.querySelectorAll('.puce input[type="checkbox"]').forEach((c) => {
    c.addEventListener("change", async () => {
      const i = parseInt(c.dataset.index, 10);
      if (c.dataset.type === "hub") etat.config.hubs[i].actif = c.checked;
      else etat.config.minerais[i].actif = c.checked;
      c.closest(".puce").classList.toggle("actif", c.checked);
      await sauverConfig();
      chargerMarche(true).catch(() => {});
    });
  });
}

async function sauverConfig() {
  await api("/api/config", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(etat.config),
  });
}

// ---------------------------------------------------------------------
//  Parametres
// ---------------------------------------------------------------------
function remplireParams() {
  const c = etat.config;
  $("inp-courtage").value = c.frais.courtage_pct;
  $("inp-taxe").value = c.frais.taxe_vente_pct;
  $("inp-volmin").value = c.filtre.volume_min;
  $("inp-pas").value = c.strategie.pas_sous_cote;
  $("sel-comportement").value = c.strategie.comportement;
  $("inp-aberrant").checked = !!c.filtre.ignorer_prix_aberrants;
  $("inp-ecart").value = c.filtre.ecart_aberrant_pct;
  $("inp-cache").value = c.duree_cache_esi_s;
  $("inp-limiter-station").checked = c.limiter_station !== false;
}

async function sauverParams() {
  const c = etat.config;
  c.frais.courtage_pct = num("inp-courtage", 3);
  c.frais.taxe_vente_pct = num("inp-taxe", 8);
  c.filtre.volume_min = Math.max(1, Math.round(num("inp-volmin", 1)));
  c.strategie.pas_sous_cote = Math.max(0.01, num("inp-pas", 0.01));
  c.strategie.comportement = $("sel-comportement").value;
  c.filtre.ignorer_prix_aberrants = $("inp-aberrant").checked;
  c.filtre.ecart_aberrant_pct = Math.min(95, Math.max(5, num("inp-ecart", 60)));
  c.duree_cache_esi_s = Math.max(30, Math.round(num("inp-cache", 300)));
  c.limiter_station = $("inp-limiter-station").checked;
  await sauverConfig();
  $("params-info").textContent = "Enregistré.";
  setTimeout(() => ($("params-info").textContent = ""), 2500);
  chargerMarche(true).catch(() => {});
  remplireParams();
}

function num(id, defaut) {
  const v = parseFloat($(id).value);
  return isNaN(v) ? defaut : v;
}

// ---------------------------------------------------------------------
//  Ajouter un minerai (resolution du type_id via ESI)
// ---------------------------------------------------------------------
async function ajouterMinerai() {
  const nom = $("inp-nouveau-minerai").value.trim();
  if (!nom) return;
  $("ajout-info").textContent = "recherche…";
  try {
    const r = await api("/api/resoudre?nom=" + encodeURIComponent(nom));
    if (etat.config.minerais.some((m) => m.nom.toLowerCase() === r.nom.toLowerCase())) {
      $("ajout-info").textContent = "déjà présent.";
      return;
    }
    etat.config.minerais.push({ nom: r.nom, type_id: r.type_id, actif: true });
    await sauverConfig();
    $("inp-nouveau-minerai").value = "";
    $("ajout-info").textContent = r.nom + " ajouté (type " + r.type_id + ").";
    rendreMinerais();
    chargerMarche(true).catch(() => {});
  } catch (e) {
    $("ajout-info").textContent = "introuvable : " + nom;
  }
}

// ---------------------------------------------------------------------
//  Copie dans le presse-papiers
// ---------------------------------------------------------------------
async function copier(texte, bouton) {
  try {
    await navigator.clipboard.writeText(String(texte));
    if (bouton) {
      const ancien = bouton.textContent;
      bouton.textContent = "copié !";
      setTimeout(() => (bouton.textContent = ancien), 1200);
    }
  } catch { /* presse-papiers refuse */ }
}

// ---------------------------------------------------------------------
//  Minuteur
// ---------------------------------------------------------------------
function relancerCompteARebours() {
  clearInterval(etat.minuteur);
  clearInterval(etat.battement);
  if (!etat.intervalle) { $("compte-a-rebours").textContent = "manuel"; return; }
  etat.secondes = etat.intervalle;
  $("compte-a-rebours").textContent = "dans " + etat.secondes + " s";
  etat.minuteur = setInterval(() => chargerMarche(false).catch(() => {}), etat.intervalle * 1000);
  etat.battement = setInterval(() => {
    etat.secondes = Math.max(0, etat.secondes - 1);
    $("compte-a-rebours").textContent = "dans " + etat.secondes + " s";
  }, 1000);
}

// ---------------------------------------------------------------------
//  Branchements + demarrage
// ---------------------------------------------------------------------
function brancherEvenements() {
  $("btn-actualiser").addEventListener("click", () => chargerMarche(true).catch(() => {}));
  $("btn-params").addEventListener("click", () => {
    $("panneau-params").hidden = !$("panneau-params").hidden;
  });
  $("btn-sauver-params").addEventListener("click", () => sauverParams().catch(() => {}));
  $("sel-intervalle").addEventListener("change", () => {
    etat.intervalle = parseInt($("sel-intervalle").value, 10);
    relancerCompteARebours();
  });
  $("inp-recherche").addEventListener("input", () => {
    etat.recherche = $("inp-recherche").value;
    rendreTout();
  });
  $("sel-courbe-minerai").addEventListener("change", () => {
    etat.mineralCourbe = $("sel-courbe-minerai").value;
    chargerHistorique().catch(() => {});
  });
  $("sel-courbe-heures").addEventListener("change", () => {
    etat.heuresCourbe = parseInt($("sel-courbe-heures").value, 10) || 0;
    chargerHistorique().catch(() => {});
  });
  $("btn-ajouter-minerai").addEventListener("click", () => ajouterMinerai());
  $("inp-nouveau-minerai").addEventListener("keydown", (e) => {
    if (e.key === "Enter") ajouterMinerai();
  });

  // Achat-revente
  $("sel-ar-depart").addEventListener("change", () => {
    etat.arDepart = $("sel-ar-depart").value;
    rendreAR();
  });
  $("sel-ar-arrivee").addEventListener("change", () => {
    etat.arArrivee = $("sel-ar-arrivee").value;
    rendreAR();
  });
  $("sel-ar-minerai").addEventListener("change", () => {
    etat.arMineral = $("sel-ar-minerai").value;
    majAR(true).catch(() => {});
  });
  $("inp-ar-heures").addEventListener("input", () => rendreAR());
  $("inp-ar-min").addEventListener("input", () => rendreAR());
  $("btn-ar-estimer").addEventListener("click", () => majAR(true).catch(() => {}));
  $("btn-notif").addEventListener("click", async () => {
    if (!("Notification" in window)) return;
    if (Notification.permission !== "granted") await Notification.requestPermission();
    etat.notif = Notification.permission === "granted";
    $("btn-notif").classList.toggle("actif", etat.notif);
    $("btn-notif").textContent = etat.notif ? "🔔 Notifs actives" : "🔔 Notifier";
  });
}

async function demarrer() {
  brancherEvenements();
  try {
    await chargerConfig();
    const iv = String(etat.config.intervalle_sondage_s);
    if ([...$("sel-intervalle").options].some((o) => o.value === iv)) {
      $("sel-intervalle").value = iv;
    }
    etat.intervalle = parseInt($("sel-intervalle").value, 10);
    await chargerMarche(true);
  } catch (e) {
    marquerEtat("err", "démarrage impossible");
  }
}

demarrer();
