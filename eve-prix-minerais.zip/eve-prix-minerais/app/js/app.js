"use strict";

// =====================================================================
//  EVE - Prix des minerais  ::  logique de l'application
//  Le serveur (serveur.ps1) fournit les donnees ESI et les prix
//  conseilles. Cette page affiche, compare a tes ordres, et alerte.
// =====================================================================

const nf2 = new Intl.NumberFormat("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const nf0 = new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 0 });

const $ = (id) => document.getElementById(id);
const prix = (n) => (n === null || n === undefined ? "—" : nf2.format(n));
const vol  = (n) => (n === null || n === undefined ? "—" : nf0.format(n));

const etat = {
  config: null,
  marche: null,
  ordres: chargerOrdres(),
  recherche: "",
  intervalle: 30,
  minuteur: null,
  battement: null,
  secondes: 0,
  notif: false,
  alertesPrec: 0,
  historique: null,
  mineralCourbe: null,
  heuresCourbe: 168,
};

// ---------------------------------------------------------------------
//  Mes ordres (memorises dans le navigateur)
// ---------------------------------------------------------------------
function cleOrdre(hub, mineral) { return hub + "||" + mineral; }

function chargerOrdres() {
  try { return JSON.parse(localStorage.getItem("epm_ordres") || "{}"); }
  catch { return {}; }
}
function sauverOrdres() {
  localStorage.setItem("epm_ordres", JSON.stringify(etat.ordres));
}
function ordreDe(hub, mineral) {
  return etat.ordres[cleOrdre(hub, mineral)] || null;
}

// ---------------------------------------------------------------------
//  Appels au serveur local
// ---------------------------------------------------------------------
async function api(chemin, options) {
  const rep = await fetch(chemin, options);
  if (!rep.ok) throw new Error("HTTP " + rep.status + " sur " + chemin);
  const ct = rep.headers.get("content-type") || "";
  return ct.includes("json") ? rep.json() : rep.text();
}

// ---------------------------------------------------------------------
//  Chargement
// ---------------------------------------------------------------------
async function chargerConfig() {
  etat.config = await api("/api/config");
  remplireParams();
  rendreHubs();
  rendreMinerais();
}

async function chargerMarche(force) {
  marquerEtat("chargement", "actualisation…");
  try {
    etat.marche = await api("/api/marche" + (force ? "?force=1" : ""));
    marquerEtat("ok", "ESI connecté");
    rendreTout();
  } catch (e) {
    marquerEtat("err", "erreur ESI");
    $("pied-erreurs").textContent = "Erreur : " + e.message;
    throw e;
  }
  $("maj-heure").textContent = "maj " + etat.marche.maj_lisible;
  await chargerHistorique().catch(() => {});
  relancerCompteARebours();
}

function marquerEtat(classe, texte) {
  $("pastille").className = "pastille " + classe;
  $("etat-texte").textContent = texte;
}

// ---------------------------------------------------------------------
//  Rendu
// ---------------------------------------------------------------------
function rendreTout() {
  rendreTable();
  rendreArbitrage();
  rendreAlertes();
  rendreKpis();
  majSelecteurMinerai();
  rendreCourbe();
  $("pied-source").textContent =
    "Source : ESI — API publique d'EVE Online (lecture seule). Cache ESI " +
    etat.marche.cache_secondes + " s.";
  $("pied-erreurs").textContent = (etat.marche.erreurs && etat.marche.erreurs.length)
    ? "⚠ " + etat.marche.erreurs.join("  |  ") : "";
}

function lignesFiltrees() {
  if (!etat.marche) return [];
  const q = etat.recherche.trim().toLowerCase();
  return etat.marche.lignes.filter((l) => !q || l.mineral.toLowerCase().includes(q));
}

function rendreTable() {
  const corps = $("corps-marche");
  // Ne pas reconstruire le tableau pendant que l'utilisateur saisit un prix
  // (sinon le champ perd le focus a chaque frappe).
  const actif = document.activeElement;
  if (actif && actif.closest && actif.closest("#table-marche")) return;

  const lignes = lignesFiltrees();
  if (!lignes.length) {
    corps.innerHTML = '<tr><td colspan="12" class="vide">Aucune donnée. Vérifie les minerais et hubs cochés.</td></tr>';
    return;
  }
  corps.innerHTML = lignes.map((l) => ligneHtml(l)).join("");

  corps.querySelectorAll("input.prix-ordre").forEach((inp) => {
    inp.addEventListener("input", () => {
      const hub = inp.dataset.hub, mineral = inp.dataset.mineral;
      const sens = corps.querySelector(
        `.sens-ordre[data-hub="${cssEchappe(hub)}"][data-mineral="${cssEchappe(mineral)}"]`
      ).value;
      const val = parseFloat(inp.value.replace(",", "."));
      if (isNaN(val) || val <= 0) delete etat.ordres[cleOrdre(hub, mineral)];
      else etat.ordres[cleOrdre(hub, mineral)] = { prix: val, sens: sens };
      sauverOrdres();
      const l = etat.marche.lignes.find((x) => x.hub === hub && x.mineral === mineral);
      majCellulesLigne(inp.closest("tr"), l);
      rendreAlertes();
      rendreKpis();
    });
  });
  corps.querySelectorAll("select.sens-ordre").forEach((sel) => {
    sel.addEventListener("change", () => {
      const hub = sel.dataset.hub, mineral = sel.dataset.mineral;
      const entree = etat.ordres[cleOrdre(hub, mineral)];
      if (entree) { entree.sens = sel.value; sauverOrdres(); }
      const l = etat.marche.lignes.find((x) => x.hub === hub && x.mineral === mineral);
      majCellulesLigne(sel.closest("tr"), l);
      rendreAlertes();
      rendreKpis();
    });
  });
  corps.querySelectorAll("button.copier").forEach((b) => {
    b.addEventListener("click", () => copier(b.dataset.prix, b));
  });
}

function cssEchappe(s) { return s.replace(/"/g, '\\"'); }

function ligneHtml(l) {
  const o = ordreDe(l.hub, l.mineral);
  const { classe, texte, nouveau } = evalEtat(l, o);
  const sens = o ? o.sens : "vente";

  const cellAchat = l.achat_max === null
    ? '<span class="tag neutre">—</span>'
    : `${prix(l.achat_max)} <small>${vol(l.achat_volume)}</small>`;
  const cellVente = l.vente_min === null
    ? '<span class="tag neutre">—</span>'
    : `${prix(l.vente_min)} <small>${vol(l.vente_volume)}</small>`;

  const ecart = l.spread === null ? "—"
    : `<span class="${l.spread < 0 ? "tag mauvais" : ""}">${prix(l.spread)}</span>`;

  const cellNouveau = nouveau === null
    ? '<span class="tag neutre">—</span>'
    : `<b class="mono">${prix(nouveau)}</b>`;

  const boutonNouveau = nouveau === null ? "" :
    `<button class="copier" data-prix="${nouveau}" title="Copier ${nouveau}">copier</button>`;

  return `<tr>
    <td>${l.hub}</td>
    <td>${l.mineral}</td>
    <td class="num mono">${cellAchat}</td>
    <td class="num mono">${cellVente}</td>
    <td class="num mono">${ecart}</td>
    <td class="num mono">${prix(l.prix_vente)}</td>
    <td class="num mono">${prix(l.prix_achat)}</td>
    <td class="num mono">${prix(l.net_vente_posee)}</td>
    <td>
      <input class="prix-ordre" type="number" step="0.01" min="0"
             data-hub="${esc(l.hub)}" data-mineral="${esc(l.mineral)}"
             value="${o ? o.prix : ""}" placeholder="—">
      <select class="sens-ordre" data-hub="${esc(l.hub)}" data-mineral="${esc(l.mineral)}">
        <option value="vente"${sens === "vente" ? " selected" : ""}>vente</option>
        <option value="achat"${sens === "achat" ? " selected" : ""}>achat</option>
      </select>
    </td>
    <td data-role="etat"><span class="tag ${classe}">${texte}</span></td>
    <td class="num" data-role="nouveau">${cellNouveau}</td>
    <td data-role="action">${boutonNouveau}</td>
  </tr>`;
}

// Met a jour une seule ligne (etat / nouveau prix / bouton) sans reconstruire
// le tableau : indispensable pour ne pas perdre le focus pendant la saisie.
function majCellulesLigne(tr, l) {
  if (!tr || !l) return;
  const o = ordreDe(l.hub, l.mineral);
  const { classe, texte, nouveau } = evalEtat(l, o);
  const celEtat = tr.querySelector('[data-role="etat"]');
  if (celEtat) celEtat.innerHTML = `<span class="tag ${classe}">${texte}</span>`;
  const celNouveau = tr.querySelector('[data-role="nouveau"]');
  if (celNouveau) celNouveau.innerHTML = nouveau === null
    ? '<span class="tag neutre">—</span>' : `<b class="mono">${prix(nouveau)}</b>`;
  const celAction = tr.querySelector('[data-role="action"]');
  if (celAction) {
    celAction.innerHTML = nouveau === null ? ""
      : `<button class="copier" data-prix="${nouveau}" title="Copier ${nouveau}">copier</button>`;
    const b = celAction.querySelector("button.copier");
    if (b) b.addEventListener("click", () => copier(b.dataset.prix, b));
  }
}

function esc(s) {
  return String(s).replace(/&/g, "&amp;").replace(/"/g, "&quot;")
    .replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// Etat d'un ordre par rapport au marche.
function evalEtat(l, o) {
  if (!o) return { classe: "neutre", texte: "—", nouveau: null };
  if (o.sens === "vente") {
    if (l.vente_min === null) return { classe: "neutre", texte: "pas de vente", nouveau: null };
    if (o.prix <= l.vente_min) return { classe: "bon", texte: "meilleur", nouveau: l.prix_vente };
    return { classe: "mauvais", texte: "dépassé", nouveau: l.prix_vente };
  } else {
    if (l.achat_max === null) return { classe: "neutre", texte: "pas d'achat", nouveau: null };
    if (o.prix >= l.achat_max) return { classe: "bon", texte: "meilleur", nouveau: l.prix_achat };
    return { classe: "mauvais", texte: "dépassé", nouveau: l.prix_achat };
  }
}

// ---------------------------------------------------------------------
//  Arbitrage inter-hubs
// ---------------------------------------------------------------------
function calculerArbitrage() {
  if (!etat.marche) return [];
  const parMineral = {};
  for (const l of etat.marche.lignes) {
    (parMineral[l.mineral] = parMineral[l.mineral] || []).push(l);
  }
  const frais = etat.marche.frais;
  const courtage = frais.courtage_pct / 100, taxe = frais.taxe_vente_pct / 100;
  const res = [];
  for (const [mineral, lignes] of Object.entries(parMineral)) {
    let achat = null, vente = null;
    for (const l of lignes) {
      if (l.vente_min !== null && (!achat || l.vente_min < achat.vente_min)) achat = l;
      if (l.achat_max !== null && (!vente || l.achat_max > vente.achat_max)) vente = l;
    }
    if (!achat || !vente || achat.hub === vente.hub) continue;
    const brut = vente.achat_max - achat.vente_min;
    const net = vente.achat_max * (1 - taxe) - achat.vente_min * (1 + courtage);
    if (brut <= 0) continue;
    res.push({ mineral, achat, vente, brut, net });
  }
  res.sort((a, b) => b.net - a.net);
  return res;
}

function rendreArbitrage() {
  const lignes = calculerArbitrage();
  const corps = $("corps-arbi");
  if (!lignes.length) {
    corps.innerHTML = '<tr><td colspan="7" class="vide">Pas d\'opportunité (il faut au moins 2 hubs suivis).</td></tr>';
    return;
  }
  corps.innerHTML = lignes.map((a) => `<tr>
    <td>${a.mineral}</td>
    <td>${a.achat.hub}</td>
    <td class="num mono">${prix(a.achat.vente_min)}</td>
    <td>${a.vente.hub}</td>
    <td class="num mono">${prix(a.vente.achat_max)}</td>
    <td class="num mono">${prix(a.brut)}</td>
    <td class="num mono" style="color:${a.net > 0 ? "var(--bon)" : "var(--mauvais)"}">${prix(a.net)}</td>
  </tr>`).join("");
}

// ---------------------------------------------------------------------
//  Courbe du prix de vente moyen dans le temps
//  Le serveur enregistre un point par heure et par station (hub x minerai).
//  On trace, pour le minerai choisi, une courbe par station : trait plein =
//  moyenne du carnet, trait pointille = meilleure vente.
// ---------------------------------------------------------------------
const COULEURS_COURBE = ["#46b3a0", "#d9b45b", "#6fa8dc", "#e0895a", "#b47fe0", "#7fd66f", "#e06f9a", "#c0c8d0"];

async function chargerHistorique() {
  if (!etat.mineralCourbe) { etat.historique = null; rendreCourbe(); return; }
  const url = "/api/historique?mineral=" + encodeURIComponent(etat.mineralCourbe) +
              "&heures=" + etat.heuresCourbe;
  etat.historique = await api(url);
  rendreCourbe();
}

function majSelecteurMinerai() {
  const sel = $("sel-courbe-minerai");
  if (!sel) return;
  const noms = etat.marche ? etat.marche.minerais.map((m) => m.nom) : [];
  if (!noms.length) return;
  if (!etat.mineralCourbe || !noms.includes(etat.mineralCourbe)) etat.mineralCourbe = noms[0];
  const actuels = [...sel.options].map((o) => o.value);
  const identique = actuels.length === noms.length && actuels.every((v, i) => v === noms[i]);
  if (!identique) sel.innerHTML = noms.map((n) => `<option value="${esc(n)}">${esc(n)}</option>`).join("");
  sel.value = etat.mineralCourbe;
}

// Abrege les grands nombres (ISK) pour les etiquettes de l'axe vertical.
function prixAxe(v) {
  const a = Math.abs(v);
  if (a >= 1e9) return (v / 1e9).toFixed(2).replace(".", ",") + " G";
  if (a >= 1e6) return (v / 1e6).toFixed(2).replace(".", ",") + " M";
  if (a >= 1e3) return (v / 1e3).toFixed(1).replace(".", ",") + " k";
  return nf0.format(v);
}

function labelTemps(d, span) {
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  const jj = String(d.getDate()).padStart(2, "0");
  const mo = String(d.getMonth() + 1).padStart(2, "0");
  if (span <= 48 * 3600000) return hh + ":" + mm;
  return jj + "/" + mo + " " + hh + "h";
}

function traceSerie(pts, col, pointille) {
  if (!pts.length) return "";
  const d = "M" + pts.map(([px, py]) => px.toFixed(1) + " " + py.toFixed(1)).join(" L");
  const dash = pointille ? ' stroke-dasharray="5 4" opacity="0.78"' : "";
  let out = `<path d="${d}" fill="none" stroke="${col}" stroke-width="2" stroke-linejoin="round"${dash}/>`;
  if (pts.length === 1) out += `<circle cx="${pts[0][0].toFixed(1)}" cy="${pts[0][1].toFixed(1)}" r="2.6" fill="${col}"/>`;
  return out;
}

function rendreCourbe() {
  const zone = $("courbe-svg");
  const leg = $("legende-courbe");
  const info = $("courbe-info");
  if (!zone) return;
  if (info) { info.style.display = "none"; info.innerHTML = ""; }

  const histo = etat.historique;
  const series = (histo && histo.series ? histo.series : []).filter((s) => s.points && s.points.length);
  if (!series.length) {
    zone.innerHTML = '<p class="vide">Pas encore de données pour ce minerai. La courbe se ' +
      "remplit au fil des heures (un point par heure), tant que l'application tourne.</p>";
    if (leg) leg.innerHTML = "";
    return;
  }

  let tmin = Infinity, tmax = -Infinity, vmin = Infinity, vmax = -Infinity;
  for (const s of series) {
    for (const p of s.points) {
      const t = Date.parse(p.t);
      if (!isNaN(t)) { if (t < tmin) tmin = t; if (t > tmax) tmax = t; }
      for (const v of [p.pm, p.vm]) {
        if (v != null && isFinite(v) && v > 0) { if (v < vmin) vmin = v; if (v > vmax) vmax = v; }
      }
    }
  }
  if (!isFinite(tmin) || !isFinite(vmin)) {
    zone.innerHTML = '<p class="vide">Pas de prix de vente exploitable dans cette période.</p>';
    if (leg) leg.innerHTML = "";
    return;
  }
  if (tmax <= tmin) tmax = tmin + 3600000;
  let marges = (vmax - vmin) * 0.08;
  if (marges <= 0) marges = Math.max(vmax * 0.05, 0.01);
  let vlo = vmin - marges, vhi = vmax + marges;
  if (vlo < 0) vlo = 0;

  const W = 1000, H = 340, padL = 66, padR = 16, padT = 16, padB = 32;
  const span = tmax - tmin;
  const X = (t) => padL + (t - tmin) / span * (W - padL - padR);
  const Y = (v) => H - padB - (v - vlo) / (vhi - vlo) * (H - padT - padB);

  let svg = `<svg viewBox="0 0 ${W} ${H}" class="graphique">`;
  const ny = 4;
  for (let i = 0; i <= ny; i++) {
    const v = vlo + (vhi - vlo) * i / ny;
    const yy = Y(v);
    svg += `<line x1="${padL}" y1="${yy.toFixed(1)}" x2="${W - padR}" y2="${yy.toFixed(1)}" class="grille"/>`;
    svg += `<text x="${padL - 8}" y="${(yy + 4).toFixed(1)}" class="axe axe-y" text-anchor="end">${prixAxe(v)}</text>`;
  }
  const nx = 5;
  for (let i = 0; i <= nx; i++) {
    const t = tmin + span * i / nx;
    const xx = X(t);
    svg += `<line x1="${xx.toFixed(1)}" y1="${padT}" x2="${xx.toFixed(1)}" y2="${H - padB}" class="grille grille-v"/>`;
    svg += `<text x="${xx.toFixed(1)}" y="${H - padB + 18}" class="axe" text-anchor="middle">${labelTemps(new Date(t), span)}</text>`;
  }

  const legende = [];
  series.forEach((s, i) => {
    const col = COULEURS_COURBE[i % COULEURS_COURBE.length];
    legende.push({ hub: s.hub, couleur: col });
    const ptsPM = [], ptsVM = [];
    for (const p of s.points) {
      const t = Date.parse(p.t); if (isNaN(t)) continue;
      if (p.pm != null) ptsPM.push([X(t), Y(p.pm)]);
      if (p.vm != null && p.vm > 0) ptsVM.push([X(t), Y(p.vm)]);
    }
    svg += traceSerie(ptsVM, col, true);
    svg += traceSerie(ptsPM, col, false);
  });
  svg += `<line id="curseur" x1="0" y1="${padT}" x2="0" y2="${H - padB}" class="curseur" style="display:none"/>`;
  svg += "</svg>";
  zone.innerHTML = svg;

  if (leg) {
    leg.innerHTML =
      legende.map((l) => `<span class="leg-item"><i style="background:${l.couleur}"></i>${esc(l.hub)}</span>`).join("") +
      `<span class="leg-item"><svg width="26" height="8"><line x1="1" y1="4" x2="25" y2="4" stroke="#8296ab" stroke-width="2"/></svg>moyenne du carnet</span>` +
      `<span class="leg-item"><svg width="26" height="8"><line x1="1" y1="4" x2="25" y2="4" stroke="#8296ab" stroke-width="2" stroke-dasharray="5 4"/></svg>meilleure vente</span>`;
  }

  // Survol : ligne verticale + infobulle des valeurs a l'heure la plus proche.
  const svgEl = zone.querySelector("svg");
  const curseur = zone.querySelector("#curseur");
  const tousTemps = [...new Set(series.flatMap((s) => s.points.map((p) => p.t)))]
    .map((t) => Date.parse(t)).filter((t) => !isNaN(t)).sort((a, b) => a - b);
  if (!tousTemps.length || !info) return;

  svgEl.addEventListener("mousemove", (ev) => {
    const rect = svgEl.getBoundingClientRect();
    const px = (ev.clientX - rect.left) / rect.width * W;
    let meilleur = tousTemps[0], bd = Infinity;
    for (const t of tousTemps) { const d = Math.abs(X(t) - px); if (d < bd) { bd = d; meilleur = t; } }
    curseur.setAttribute("x1", X(meilleur).toFixed(1));
    curseur.setAttribute("x2", X(meilleur).toFixed(1));
    curseur.style.display = "";

    let html = `<b>${labelTemps(new Date(meilleur), span)}</b>`;
    series.forEach((s, i) => {
      const p = s.points.find((x) => Date.parse(x.t) === meilleur);
      if (!p) return;
      const col = COULEURS_COURBE[i % COULEURS_COURBE.length];
      html += `<div class="tt-ligne"><i style="background:${col}"></i>${esc(s.hub)}` +
        `<span class="mono">${prix(p.pm)} <small>moy</small> · ${prix(p.vm)} <small>min</small></span></div>`;
    });
    info.innerHTML = html;
    info.style.display = "";
    const left = X(meilleur) / W * rect.width;
    info.style.left = Math.min(Math.max(left, 90), Math.max(rect.width - 90, 90)) + "px";
    info.style.top = "10px";
  });
  svgEl.addEventListener("mouseleave", () => {
    curseur.style.display = "none";
    info.style.display = "none";
  });
}

// ---------------------------------------------------------------------
//  Alertes
// ---------------------------------------------------------------------
function alertes() {
  if (!etat.marche) return [];
  const q = etat.recherche.trim().toLowerCase();
  return etat.marche.lignes
    .filter((l) => !q || l.mineral.toLowerCase().includes(q))
    .map((l) => ({ l, e: evalEtat(l, ordreDe(l.hub, l.mineral)) }))
    .filter((x) => x.e.classe === "mauvais");
}

function rendreAlertes() {
  const a = alertes();
  const bloc = $("bloc-alertes");
  if (!a.length) { bloc.hidden = true; $("liste-alertes").innerHTML = ""; etat.alertesPrec = 0; return; }
  bloc.hidden = false;
  $("liste-alertes").innerHTML = a.map(({ l, e }) => {
    const o = ordreDe(l.hub, l.mineral);
    const sens = o.sens === "vente" ? "vente" : "achat";
    const meilleur = sens === "vente" ? l.vente_min : l.achat_max;
    return `<div class="alerte">
      <b>${l.hub} · ${l.mineral}</b>
      <span>ton ordre ${sens} à <span class="mono">${prix(o.prix)}</span>
            — le carnet est à <span class="mono">${prix(meilleur)}</span></span>
      <span class="fl">
        <span>nouveau prix : <b class="mono">${prix(e.nouveau)}</b></span>
        <button class="copier" data-prix="${e.nouveau}">copier</button>
      </span>
    </div>`;
  }).join("");
  $("liste-alertes").querySelectorAll("button.copier").forEach((b) => {
    b.addEventListener("click", () => copier(b.dataset.prix, b));
  });
  if (etat.notif && a.length > etat.alertesPrec && "Notification" in window) {
    try {
      new Notification("EVE · ordre dépassé", {
        body: a.length + " ordre(s) à reposer — ouvre le tableau pour le nouveau prix.",
      });
    } catch { /* ignore */ }
  }
  etat.alertesPrec = a.length;
}

function rendreKpis() {
  if (!etat.marche) return;
  $("kpi-hubs").textContent = etat.marche.hubs.length;
  $("kpi-minerais").textContent = etat.marche.minerais.length;
  const a = alertes();
  $("kpi-alertes").textContent = a.length;
  const arbi = calculerArbitrage();
  $("kpi-arbi").textContent = arbi.length ? prix(arbi[0].net) : "—";
}

// ---------------------------------------------------------------------
//  Hubs & minerais (puces a cocher)
// ---------------------------------------------------------------------
function rendreHubs() {
  $("liste-hubs").innerHTML = etat.config.hubs.map((h, i) => `
    <label class="puce ${h.actif ? "actif" : ""}">
      <input type="checkbox" data-type="hub" data-index="${i}" ${h.actif ? "checked" : ""}>
      ${h.nom}
    </label>`).join("");
  brancherPuces();
}

function rendreMinerais() {
  $("liste-minerais").innerHTML = etat.config.minerais.map((m, i) => `
    <label class="puce ${m.actif ? "actif" : ""}">
      <input type="checkbox" data-type="minerai" data-index="${i}" ${m.actif ? "checked" : ""}>
      ${m.nom}
    </label>`).join("");
  brancherPuces();
}

function brancherPuces() {
  document.querySelectorAll('.puce input[type="checkbox"]').forEach((c) => {
    c.addEventListener("change", async () => {
      const i = parseInt(c.dataset.index, 10);
      if (c.dataset.type === "hub") etat.config.hubs[i].actif = c.checked;
      else etat.config.minerais[i].actif = c.checked;
      c.closest(".puce").classList.toggle("actif", c.checked);
      await sauverConfig();
      chargerMarche(true).catch(() => {});
    });
  });
}

async function sauverConfig() {
  await api("/api/config", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(etat.config),
  });
}

// ---------------------------------------------------------------------
//  Parametres
// ---------------------------------------------------------------------
function remplireParams() {
  const c = etat.config;
  $("inp-courtage").value = c.frais.courtage_pct;
  $("inp-taxe").value = c.frais.taxe_vente_pct;
  $("inp-volmin").value = c.filtre.volume_min;
  $("inp-pas").value = c.strategie.pas_sous_cote;
  $("sel-comportement").value = c.strategie.comportement;
  $("inp-aberrant").checked = !!c.filtre.ignorer_prix_aberrants;
  $("inp-ecart").value = c.filtre.ecart_aberrant_pct;
  $("inp-cache").value = c.duree_cache_esi_s;
  $("inp-limiter-station").checked = c.limiter_station !== false;
}

async function sauverParams() {
  const c = etat.config;
  c.frais.courtage_pct = num("inp-courtage", 3);
  c.frais.taxe_vente_pct = num("inp-taxe", 8);
  c.filtre.volume_min = Math.max(1, Math.round(num("inp-volmin", 1)));
  c.strategie.pas_sous_cote = Math.max(0.01, num("inp-pas", 0.01));
  c.strategie.comportement = $("sel-comportement").value;
  c.filtre.ignorer_prix_aberrants = $("inp-aberrant").checked;
  c.filtre.ecart_aberrant_pct = Math.min(95, Math.max(5, num("inp-ecart", 60)));
  c.duree_cache_esi_s = Math.max(30, Math.round(num("inp-cache", 300)));
  c.limiter_station = $("inp-limiter-station").checked;
  await sauverConfig();
  $("params-info").textContent = "Enregistré.";
  setTimeout(() => ($("params-info").textContent = ""), 2500);
  chargerMarche(true).catch(() => {});
  remplireParams();
}

function num(id, defaut) {
  const v = parseFloat($(id).value);
  return isNaN(v) ? defaut : v;
}

// ---------------------------------------------------------------------
//  Ajouter un minerai (resolution du type_id via ESI)
// ---------------------------------------------------------------------
async function ajouterMinerai() {
  const nom = $("inp-nouveau-minerai").value.trim();
  if (!nom) return;
  $("ajout-info").textContent = "recherche…";
  try {
    const r = await api("/api/resoudre?nom=" + encodeURIComponent(nom));
    if (etat.config.minerais.some((m) => m.nom.toLowerCase() === r.nom.toLowerCase())) {
      $("ajout-info").textContent = "déjà présent.";
      return;
    }
    etat.config.minerais.push({ nom: r.nom, type_id: r.type_id, actif: true });
    await sauverConfig();
    $("inp-nouveau-minerai").value = "";
    $("ajout-info").textContent = r.nom + " ajouté (type " + r.type_id + ").";
    rendreMinerais();
    chargerMarche(true).catch(() => {});
  } catch (e) {
    $("ajout-info").textContent = "introuvable : " + nom;
  }
}

// ---------------------------------------------------------------------
//  Copie dans le presse-papiers
// ---------------------------------------------------------------------
async function copier(texte, bouton) {
  try {
    await navigator.clipboard.writeText(String(texte));
    if (bouton) {
      const ancien = bouton.textContent;
      bouton.textContent = "copié !";
      setTimeout(() => (bouton.textContent = ancien), 1200);
    }
  } catch { /* presse-papiers refuse */ }
}

// ---------------------------------------------------------------------
//  Minuteur
// ---------------------------------------------------------------------
function relancerCompteARebours() {
  clearInterval(etat.minuteur);
  clearInterval(etat.battement);
  if (!etat.intervalle) { $("compte-a-rebours").textContent = "manuel"; return; }
  etat.secondes = etat.intervalle;
  $("compte-a-rebours").textContent = "dans " + etat.secondes + " s";
  etat.minuteur = setInterval(() => chargerMarche(false).catch(() => {}), etat.intervalle * 1000);
  etat.battement = setInterval(() => {
    etat.secondes = Math.max(0, etat.secondes - 1);
    $("compte-a-rebours").textContent = "dans " + etat.secondes + " s";
  }, 1000);
}

// ---------------------------------------------------------------------
//  Branchements + demarrage
// ---------------------------------------------------------------------
function brancherEvenements() {
  $("btn-actualiser").addEventListener("click", () => chargerMarche(true).catch(() => {}));
  $("btn-params").addEventListener("click", () => {
    $("panneau-params").hidden = !$("panneau-params").hidden;
  });
  $("btn-sauver-params").addEventListener("click", () => sauverParams().catch(() => {}));
  $("sel-intervalle").addEventListener("change", () => {
    etat.intervalle = parseInt($("sel-intervalle").value, 10);
    relancerCompteARebours();
  });
  $("inp-recherche").addEventListener("input", () => {
    etat.recherche = $("inp-recherche").value;
    rendreTout();
  });
  $("sel-courbe-minerai").addEventListener("change", () => {
    etat.mineralCourbe = $("sel-courbe-minerai").value;
    chargerHistorique().catch(() => {});
  });
  $("sel-courbe-heures").addEventListener("change", () => {
    etat.heuresCourbe = parseInt($("sel-courbe-heures").value, 10) || 0;
    chargerHistorique().catch(() => {});
  });
  $("btn-ajouter-minerai").addEventListener("click", () => ajouterMinerai());
  $("inp-nouveau-minerai").addEventListener("keydown", (e) => {
    if (e.key === "Enter") ajouterMinerai();
  });
  $("btn-notif").addEventListener("click", async () => {
    if (!("Notification" in window)) return;
    if (Notification.permission !== "granted") await Notification.requestPermission();
    etat.notif = Notification.permission === "granted";
    $("btn-notif").classList.toggle("actif", etat.notif);
    $("btn-notif").textContent = etat.notif ? "🔔 Notifs actives" : "🔔 Notifier";
  });
}

async function demarrer() {
  brancherEvenements();
  try {
    await chargerConfig();
    const iv = String(etat.config.intervalle_sondage_s);
    if ([...$("sel-intervalle").options].some((o) => o.value === iv)) {
      $("sel-intervalle").value = iv;
    }
    etat.intervalle = parseInt($("sel-intervalle").value, 10);
    await chargerMarche(true);
  } catch (e) {
    marquerEtat("err", "démarrage impossible");
  }
}

demarrer();
