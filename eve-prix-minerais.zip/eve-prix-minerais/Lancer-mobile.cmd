@echo off
rem EVE - Prix des minerais : version MOBILE
rem Ouvre le serveur sur le reseau local pour l'utiliser depuis un telephone
rem connecte au meme Wi-Fi. Windows demande les droits administrateur
rem (necessaire pour ouvrir un port reseau).
setlocal
cd /d "%~dp0"

net session >nul 2>&1
if %errorlevel%==0 (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0serveur.ps1" -Reseau
) else (
    echo Demande des droits administrateur pour ouvrir l'acces reseau...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -Verb RunAs -FilePath powershell -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File','%~dp0serveur.ps1','-Reseau')"
)
endlocal
