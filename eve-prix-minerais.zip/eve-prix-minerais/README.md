# EVE · Prix des minerais

Un programme local qui suit **en direct** le prix des minerais dans les hubs
commerciaux que tu choisis, et calcule pour toi **le prix à poser** (sous-cote)
pour repasser devant la concurrence. Il te prévient quand un de tes ordres vient
d'être dépassé, avec le nouveau prix exact et un bouton pour le copier.

Aucune installation : une page web + un petit serveur local. **Double-clique
`Lancer.cmd`**.

---

## Avertissement honnête : le programme ne pose pas les ordres à ta place

L'API officielle d'EVE (ESI) est **en lecture seule** pour le marché. Aucun
programme, le mien ou un autre, ne peut poser, modifier ou annuler un ordre via
l'API. Poser un ordre passe obligatoirement par l'interface du client EVE.

Ce programme fait donc la partie que l'on peut automatiser sans tricher :

- il lit le carnet d'ordres réel (achat/vente) de chaque minerai dans chaque hub ;
- il en déduit **le meilleur prix d'achat, le meilleur prix de vente, l'écart** ;
- il calcule **le prix conseillé** : meilleure vente − 0,01 ISK (ou meilleur
  achat + 0,01), net de tes frais ;
- il **surveille tes ordres** et t'alerte dès que tu es dépassé, avec le nouveau
  prix à taper dans le jeu.

C'est le maximum faisable honnêtement. La suite (piloter le client EVE à ta
place) est expliquée dans « Pour aller plus loin » — et pourquoi je ne l'ai pas
mise par défaut.

---

## Utilisation

1. Double-clique **`Lancer.cmd`**. Une fenêtre noire s'ouvre, le navigateur
   arrive sur l'application.
2. **Coche les hubs** à suivre (Jita, Amarr, Dodixie, Rens, Hek) en bas de page.
3. **Coche les minerais** qui t'intéressent (les minerais compressés et les
   minerais rares sont là, décochés par défaut).
4. Regarde le tableau : pour chaque hub × minerai, tu as le carnet et le **prix
   conseillé**.
5. Dans la colonne **« Mon ordre »**, tape le prix auquel **tu** as posé ton
   ordre et choisis *vente* ou *achat*. L'application mémorise ta saisie.
6. Si un ordre passe en rouge **« dépassé »**, la bannière du haut affiche le
   **nouveau prix** : clique **copier**, puis colle-le dans la fenêtre de marché
   d'EVE.

Pour arrêter : ferme la fenêtre noire (ou `Ctrl+C`).

> **Le clic droit « Poser un ordre » dans EVE te demande le prix.** C'est là que
> tu colles la valeur copiée. Le programme te donne le prix, tu le poses.

---

## Version mobile

Il y a une **version mobile** pensée pour le téléphone : une page compacte en
« cartes » (au lieu du grand tableau), avec les mêmes prix conseillés, la
mémoire de tes ordres, les alertes et le bouton *Copier*.

Elle est **autonome** : le fichier `mobile/index.html` contient tout, et il
interroge **directement** l'API publique d'EVE (ESI autorise les appels depuis
un navigateur). Deux façons de l'ouvrir :

### 1. Depuis ton PC, sur le même Wi-Fi (le plus simple)

1. Double-clique **`Lancer-mobile.cmd`**. Windows demande les droits
   administrateur (nécessaire pour ouvrir un port réseau) — accepte.
2. La fenêtre noire affiche une adresse du genre
   `http://192.168.1.42:8741/mobile/`.
3. Sur le téléphone (connecté au **même Wi-Fi**), ouvre cette adresse dans le
   navigateur. Autorise l'app dans le pare-feu Windows si on te le demande.
4. Astuce : menu du navigateur → *« Ajouter à l'écran d'accueil »* pour avoir
   l'app en plein écran, comme une application.

> Le PC doit rester allumé pendant l'utilisation. C'est la même application,
> servie par ton PC, mais habillée pour le mobile.

### 2. Sur le téléphone seul (sans PC)

Le fichier `mobile/index.html` est **un seul fichier autonome**. En revanche, un
navigateur refuse en général d'appeler Internet depuis un fichier ouvert
directement (`file://`). Il faut donc le **servir en http(s)**, par exemple :

- un hébergeur statique gratuit (GitHub Pages, Netlify Drop, etc.) : tu déposes
  le fichier, tu ouvres l'adresse sur le téléphone ;
- ou n'importe quel petit serveur web local.

Dans ce cas, aucune donnée ne transite par ton PC : le téléphone parle
directement à ESI. Tes hubs, tes minerais et tes ordres sont mémorisés **sur le
téléphone** (stockage local du navigateur).

> Honnêtement : la voie « sans PC » demande un hébergement. Si tu veux du clé en
> main, la solution 1 (PC + Wi-Fi) marche tout de suite.

---

## Lire le tableau

| Colonne | Signification |
| --- | --- |
| **Achat max** | le prix le plus élevé auquel on veut t'acheter (le *bid*). Le petit nombre dessous est le volume au meilleur prix. |
| **Vente min** | le prix le plus bas auquel on vend (l'*ask*). C'est **lui** que tu dois battre si tu vends. |
| **Écart** | vente min − achat max. Positif = carnet normal. Négatif = carnet croisé (vends plutôt à l'acheteur). |
| **Prix vente conseillé** | vente min − pas de sous-cote (0,01 par défaut). Le prix à poser pour être le premier vendeur. |
| **Prix achat conseillé** | achat max + pas. Le prix à poser pour être le premier acheteur. |
| **Net (vente posée)** | ce qu'il te reste **après courtage et taxe** si ton ordre est exécuté. |
| **Mon ordre** | ton prix et le sens de ton ordre (mémorisé dans le navigateur). |
| **État** | `meilleur` (tu es premier), `dépassé` (quelqu'un est devant toi), `—` (pas d'ordre saisi). |
| **Nouveau prix** | le prix exact à reposer quand tu es dépassé. |

---

## Hubs par défaut

Chaque hub est un **hôte commercial** ; le programme lit la **station
principale** de la région (réglable).

| Hub | Région | Station principale |
| --- | --- | --- |
| Jita | The Forge (`10000002`) | Jita IV - Moon 4 - Caldari Navy Assembly Plant |
| Amarr | Domain (`10000043`) | Amarr VIII (Oris) - Emperor Family Academy |
| Dodixie | Sinq Laison (`10000032`) | Dodixie IX - Moon 20 - Federation Navy Assembly Plant |
| Rens | Heimatar (`10000030`) | Rens VI - Moon 8 - Brutor Tribe Treasury |
| Hek | Metropolis (`10000042`) | Hek VIII - Moon 12 - Boundless Creation Factory |

> Dans les faits, une grande partie des ordres « Jita » est posée dans des
> **citadelles** (structures de joueurs) autour de la station. Décoche
> *« Limiter à la station principale »* dans **Paramètres** pour voir **toute la
> région** au lieu de la seule station NPC.

---

## Réglages (bouton « Paramètres »)

| Réglage | Effet |
| --- | --- |
| **Courtage (%)** | frais de pose d'un ordre (Broker Relations). 3 % par défaut — ajuste selon tes compétences. |
| **Taxe de vente (%)** | taxe prélevée à la vente (Accounting). 8 % par défaut — ajuste selon tes compétences. |
| **Volume minimum** | ignore les ordres dont le volume restant est en dessous. Monte-le pour ignorer les miettes. |
| **Pas de sous-cote** | de combien tu passes sous la meilleure vente (0,01 ISK par défaut). |
| **Comportement** | *sous-coter* (vente min − pas) ou *s'aligner* (même prix). |
| **Ignorer les ordres à prix aberrant** | écarte les ordres « pièges » posés très loin du cœur du carnet (voir plus bas). |
| **Écart max au cœur du carnet (%)** | seuil de ce filtre. 50 % = un ordre à plus de 50 % sous/sur le cœur est ignoré. |
| **Cache ESI (s)** | durée de conservation des données avant nouvelle requête. 300 s par défaut. |
| **Limiter à la station principale du hub** | coché = la seule station NPC ; décoché = toute la région (citadelles incluses). |

---

## Comment ça marche

- **Source** : l'API publique ESI d'EVE, en *lecture seule*.
  Pour chaque couple hub × minerai, le programme demande tous les ordres du
  type dans la région (`/markets/{region}/orders/?type_id=…`) et ne garde que
  ceux de la station choisie.
- **Cache** : EVE met en cache les carnets environ **5 minutes**. Le programme
  respecte ce cache (réglable) et rafraîchit la page toutes les 15/30/60 s ou à
  la main. Le « temps réel » a donc la granularité d'EVE : c'est vif, mais pas à
  la seconde.
- **Meilleur prix** : la meilleure vente est le plus **bas** prix de vente, le
  meilleur achat le plus **haut** prix d'achat, à la station.
- **Filtre « cœur du carnet »** : certains ordres sont posés très loin des prix
  réels (une vente à 1 000 000 ISK pour « faire joli », un achat à 0,01 ISK…).
  Comme ils faussent une simple moyenne, le programme prend le **cœur** = la
  médiane des 5 meilleurs prix, puis ignore tout prix à plus de X % de ce cœur.
  Les murs d'ordres chers n'influencent donc plus le prix conseillé — c'est un
  bug que j'ai trouvé et corrigé en testant sur le carnet réel de Jita.
- **Net** : `net = prix × (1 − taxe − courtage)`. Pour un achat,
  `coût = prix × (1 + courtage)`.

---

## Pourquoi pas d'automatisation du client EVE ?

Techniquement, « ajuster le prix » *dans le jeu* voudrait dire piloter le client
EVE (capture d'écran + clics simulés). C'est :

- **contre les règles** : l'automatisation du jeu par un logiciel tiers tombe
  sous le coup des CGU de CCP et peut valoir un bannissement ;
- **fragile** : la moindre mise à jour de l'interface casse le script ;
- **inutile** la plupart du temps : tu reposes un ordre toutes les quelques
  minutes, pas toutes les secondes.

Le programme fait donc tout ce qui est permis — surveiller, calculer, alerter,
copier le prix — et te laisse le clic final dans EVE. Si tu veux malgré tout une
extension qui pilote le client, elle est possible en local, mais elle n'est pas
fournie ici à dessein.

---

## Limites connues

- **Le programme ne pose aucun ordre.** Voir l'avertissement en haut. C'est une
  limite des CGU et de l'API, pas un oubli.
- **Le carnet n'est pas à la seconde.** EVE rafraîchit ses carnets environ toutes
  les 5 minutes ; entre deux, le programme te montre ce qu'EVE lui donne.
- **Les citadelles.** Beaucoup d'ordres « de hub » sont dans des structures de
  joueurs, pas à la station NPC. Défaut : station principale. Décoche
  *« Limiter à la station principale »* pour tout voir, ou ajuste la
  `station_id` d'un hub dans `config.json`.
- **Ajouter un hub** se fait dans `config.json` (nom, `region_id`, `station_id`,
  `actif`). L'interface ne fait que cocher/décocher les hubs existants.
- **Ajouter un minerai** se fait depuis l'interface : tape son **nom exact**
  (ex. `Compressed Veldspar`) et *Ajouter*. Le `type_id` est résolu auprès d'EVE.
- **Frais par défaut génériques** (3 % courtage, 8 % taxe). Renseigne tes vrais
  pourcentages dans *Paramètres*, sinon le « Net » est approximatif.
- **Marchés peu liquides.** Sur un minerai rare, il peut n'y avoir **aucun** ordre
  (affiché `—`) ou un seul ordre, parfois farfelu. Le filtre ne peut rien
  comparer quand le carnet est vide : le prix affiché est alors simplement le
  seul ordre présent.
- Le serveur écoute en `localhost` seulement par défaut : rien ne sort de ta
  machine, sauf les requêtes vers l'API d'EVE. Le mode `-Reseau`
  (`Lancer-mobile.cmd`) ouvre le port au réseau local Wi-Fi — c'est voulu, pour
  le téléphone, et ça n'expose rien sur Internet.

---

## Structure

```
eve-prix-minerais/
  Lancer.cmd                 double-clic -> démarre le serveur + ouvre l'app
  Lancer-mobile.cmd          double-clic -> serveur accessible au Wi-Fi (téléphone)
  serveur.ps1                serveur local : fichiers + appels ESI + calcul des prix
  config.json                hubs, minerais, frais, filtre, réglages
  README.md
  app/
    index.html               interface (PC)
    styles.css               apparence
    js/app.js                logique : affichage, mes ordres, alertes, arbitrage
  mobile/
    index.html               version mobile autonome (tout-en-un, appelle ESI)
```

- `GET  /api/marche` → l'instantané complet (par hub × minerai).
- `GET  /api/config` / `POST /api/config` → lire / écrire les réglages.
- `GET  /api/resoudre?nom=…` → nom de minerai → `type_id` (via ESI).
- `GET  /api/ping` → état du serveur.
- `GET  /mobile/` → la page de la version mobile (servie par le PC).

Le port par défaut est **8741** (le programme essaie 8741 → 8761 au démarrage).

---

## Prérequis

- **Windows** (PowerShell 5.1 inclus par défaut).
- Un navigateur basé **Chromium** (Chrome ou Edge) ou Firefox.
- Rien à installer : ni Python, ni Node.
- Une connexion à Internet pour joindre l'API d'EVE.
