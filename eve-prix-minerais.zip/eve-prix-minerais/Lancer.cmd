@echo off
rem EVE - Prix des minerais : demarre le serveur local et ouvre l'application.
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0serveur.ps1"
endlocal
