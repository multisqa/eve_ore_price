#requires -Version 5.1
<#
  EVE - Prix des minerais
  -------------------------------------------------------------------------
  Programme local qui suit EN DIRECT le prix des minerais dans les hubs
  commerciaux choisis, et calcule pour toi le prix a poser (sous-cote).

  Ce qu'il fait :

    1. Il interroge l'API publique d'EVE (ESI) pour recuperer les ordres
       d'achat et de vente de chaque minerai, dans chaque hub choisi.
    2. Il en deduit le meilleur achat, la meilleure vente, l'ecart, et le
       prix conseille (meilleure vente - 0,01, ou meilleur achat + 0,01).
    3. Il applique tes frais (courtage + taxe) pour te donner le net.
    4. Il sert une page web locale qui rafraichit toute seule et te signale
       les minerais ou tu viens d'etre depasse, avec le nouveau prix a poser.

  IMPORTANT : l'API d'EVE est en LECTURE SEULE pour le marche. Aucun
  programme ne peut poser ni modifier un ordre a ta place (voir README,
  section "Ce que ce programme ne fait pas").

  Lancer avec Lancer.cmd (ou : powershell -ExecutionPolicy Bypass -File serveur.ps1)
#>
[CmdletBinding()]
param(
    [int]$Port = 0,
    [switch]$NePasOuvrir,
    # Ouvre le serveur sur le reseau local (pour y acceder depuis un telephone).
    # Windows demande les droits admin, ou une reservation "netsh http add urlacl".
    [switch]$Reseau
)

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

$Racine     = $PSScriptRoot
$AppDir     = Join-Path $Racine 'app'
$MobileDir  = Join-Path $Racine 'mobile'
$ConfigPath = Join-Path $Racine 'config.json'
$UserAgent  = 'EVE-Prix-Minerais/1.0 (outil local, PowerShell)'
$EsiBase    = 'https://esi.evetech.net/latest'

# =====================================================================
#  Configuration
# =====================================================================
function Lire-Json([string]$Chemin) {
    $texte = [IO.File]::ReadAllText($Chemin, [Text.Encoding]::UTF8)
    return $texte | ConvertFrom-Json
}

function Get-Config {
    if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) {
        throw "config.json introuvable dans $Racine. Restaure-le depuis le projet."
    }
    return Lire-Json $ConfigPath
}

function Sauver-Config($cfg) {
    $json = $cfg | ConvertTo-Json -Depth 10
    [IO.File]::WriteAllText($ConfigPath, $json, (New-Object Text.UTF8Encoding($false)))
}

$script:Config = Get-Config
if ($Port -le 0) { $Port = [int]$script:Config.port }
if ($Port -le 0) { $Port = 8741 }

# =====================================================================
#  Appels ESI + cache (on respecte le cache d'EVE : ~5 min sur le marche)
# =====================================================================
$script:CacheEsi = @{}

function Invoke-EsiHttp {
    param(
        [string]$Methode = 'GET',
        [string]$Url,
        $Corps = $null,
        [string]$TypeContenu = 'application/json'
    )
    $entetes = @{ 'Accept' = 'application/json' }
    for ($tentative = 1; $tentative -le 3; $tentative++) {
        try {
            $args = @{
                Uri             = $Url
                Method          = $Methode
                Headers         = $entetes
                UserAgent       = $UserAgent
                UseBasicParsing = $true
                TimeoutSec      = 30
            }
            if ($null -ne $Corps) {
                $args['Body']        = $Corps
                $args['ContentType'] = $TypeContenu
            }
            return Invoke-WebRequest @args
        }
        catch {
            if ($tentative -eq 3) { throw }
            Start-Sleep -Milliseconds 500
        }
    }
}

# Tous les ordres (achat + vente) d'un type dans une region, avec pagination.
function Get-OrdresEsi {
    param([int]$Region, [int]$TypeId, [switch]$Force)

    $cle = "$Region/$TypeId"
    $cache = $script:CacheEsi[$cle]
    $duree = [double]$script:Config.duree_cache_esi_s
    if ($duree -le 0) { $duree = 300 }
    if (-not $Force -and $cache -and [datetime]::UtcNow -lt $cache.Expire) {
        return $cache.Donnees
    }

    $tous  = New-Object System.Collections.ArrayList
    $page  = 1
    $pages = 1
    $expire = [datetime]::UtcNow.AddSeconds($duree)

    do {
        $url = "$EsiBase/markets/$Region/orders/?type_id=$TypeId&page=$page&datasource=tranquility"
        $rep = Invoke-EsiHttp -Url $url
        if ($page -eq 1) {
            $xp = [string]$rep.Headers['X-Pages']
            if ($xp) { $pages = [int]$xp }
        }
        $donnees = $rep.Content | ConvertFrom-Json
        foreach ($o in $donnees) { [void]$tous.Add($o) }
        $page++
    } while ($page -le $pages -and $page -le 12)

    $resultat = $tous.ToArray()
    $script:CacheEsi[$cle] = @{ Donnees = $resultat; Expire = $expire; Pris = [datetime]::UtcNow }
    return $resultat
}

# Resolution d'un nom de minerai -> type_id (via ESI)
function Resoudre-TypeId {
    param([string]$Nom)
    $corps = ConvertTo-Json -InputObject @($Nom) -Compress
    $rep = Invoke-EsiHttp -Methode 'POST' -Url "$EsiBase/universe/ids/?datasource=tranquility" -Corps $corps
    $obj = $rep.Content | ConvertFrom-Json
    if ($obj.inventory_types) {
        foreach ($it in $obj.inventory_types) {
            if ($it.name -eq $Nom) { return [int]$it.id }
        }
        return [int]$obj.inventory_types[0].id
    }
    return 0
}

# =====================================================================
#  Calcul du marche
# =====================================================================
function Get-Mediane {
    param([double[]]$Valeurs)
    if (-not $Valeurs -or $Valeurs.Count -eq 0) { return $null }
    $triees = @($Valeurs | Sort-Object)
    $n = $triees.Count
    if ($n % 2 -eq 1) { return [double]$triees[[int](($n - 1) / 2)] }
    return ([double]$triees[$n / 2 - 1] + [double]$triees[$n / 2]) / 2.0
}

function Arrondir([double]$x) {
    if ($x -lt 0) { return 0.0 }
    return [math]::Round($x, 2)
}

# Meilleur prix en ecartant un eventuel ordre "piege" pose tres loin du coeur
# du carnet (ex. une vente a 0,01 ISK ou un achat a 1 milliard pour fausser la
# lecture). On prend le coeur = mediane des N meilleurs prix, puis le premier
# prix qui reste dans +/- X % de ce coeur.
#   - tri croissant par defaut : meilleure vente = plus bas prix
#   - -Desc : meilleur achat = plus haut prix
function Get-BestTrimme {
    param([double[]]$Prix, [switch]$Desc)
    if (-not $Prix -or $Prix.Count -eq 0) { return $null }
    $s = @($Prix | Sort-Object)
    if ($Desc) { $s = @($s | Sort-Object -Descending) }
    if ($s.Count -lt 3) { return [double]$s[0] }
    if (-not $script:Config.filtre.ignorer_prix_aberrants) { return [double]$s[0] }

    $ech = 5
    if ($script:Config.filtre.echantillon) { $ech = [int]$script:Config.filtre.echantillon }
    if ($ech -lt 3) { $ech = 3 }
    if ($ech -gt $s.Count) { $ech = $s.Count }

    $coeur = Get-Mediane @($s[0..($ech - 1)])
    $e = [double]$script:Config.filtre.ecart_aberrant_pct / 100.0
    if (-not $coeur -or $coeur -le 0 -or $e -le 0) { return [double]$s[0] }

    $lo = $coeur * (1 - $e)
    $hi = $coeur * (1 + $e)
    foreach ($p in $s) { if ($p -ge $lo -and $p -le $hi) { return [double]$p } }
    return [double]$s[0]
}

function Get-Marche {
    param([switch]$Force)

    $cfg     = $script:Config
    $hubs    = @($cfg.hubs    | Where-Object { $_.actif })
    $minerais= @($cfg.minerais| Where-Object { $_.actif })
    $pas     = [double]$cfg.strategie.pas_sous_cote
    if ($pas -le 0) { $pas = 0.01 }
    $sousCoter = ([string]$cfg.strategie.comportement -ne 's_aligner')
    $volMin   = [double]$cfg.filtre.volume_min
    $limiterStation = [bool]$cfg.limiter_station
    $courtage = [double]$cfg.frais.courtage_pct / 100.0
    $taxe     = [double]$cfg.frais.taxe_vente_pct / 100.0

    $lignes  = New-Object System.Collections.ArrayList
    $erreurs = New-Object System.Collections.ArrayList

    foreach ($h in $hubs) {
        $region  = [int]$h.region_id
        $station = 0
        if ($limiterStation -and $h.station_id) { $station = [long]$h.station_id }

        foreach ($m in $minerais) {
            $tid = 0
            if ($m.type_id) { $tid = [int]$m.type_id }
            if ($tid -le 0) { continue }

            $ventes = New-Object System.Collections.ArrayList
            $achats = New-Object System.Collections.ArrayList
            try {
                $ordres = Get-OrdresEsi -Region $region -TypeId $tid -Force:$Force
                foreach ($o in $ordres) {
                    if ($station -gt 0 -and [long]$o.location_id -ne $station) { continue }
                    if ([double]$o.volume_remain -lt $volMin) { continue }
                    if ($o.is_buy_order) { [void]$achats.Add($o) } else { [void]$ventes.Add($o) }
                }
            }
            catch {
                [void]$erreurs.Add("$($h.nom) / $($m.nom) : $($_.Exception.Message)")
                continue
            }

            # meilleure vente (plus bas prix) et meilleur achat (plus haut prix),
            # en ecartant un eventuel ordre piege tres loin du coeur du carnet
            $venteMin = Get-BestTrimme -Prix @($ventes | ForEach-Object { [double]$_.price })
            $achatMax = Get-BestTrimme -Prix @($achats | ForEach-Object { [double]$_.price }) -Desc

            # volumes cumules au meilleur prix
            $venteVol = 0; $venteNb = 0
            if ($null -ne $venteMin) {
                foreach ($o in $ventes) { if ([double]$o.price -eq $venteMin) { $venteVol += [long]$o.volume_remain; $venteNb++ } }
            }
            $achatVol = 0; $achatNb = 0
            if ($null -ne $achatMax) {
                foreach ($o in $achats) { if ([double]$o.price -eq $achatMax) { $achatVol += [long]$o.volume_remain; $achatNb++ } }
            }

            # prix conseille
            $prixVente = $null; $prixAchat = $null
            if ($null -ne $venteMin) {
                $prixVente = if ($sousCoter) { Arrondir ($venteMin - $pas) } else { Arrondir $venteMin }
                if ($prixVente -le 0) { $prixVente = 0.01 }
            }
            if ($null -ne $achatMax) {
                $prixAchat = if ($sousCoter) { Arrondir ($achatMax + $pas) } else { Arrondir $achatMax }
            }

            # net apres frais
            $netVenteInstant = $null; $netVentePosee = $null; $coutAchat = $null
            if ($null -ne $achatMax)     { $netVenteInstant = Arrondir ($achatMax * (1 - $taxe)) }
            if ($null -ne $prixVente)    { $netVentePosee  = Arrondir ($prixVente * (1 - $taxe - $courtage)) }
            if ($null -ne $prixAchat)    { $coutAchat      = Arrondir ($prixAchat * (1 + $courtage)) }

            $spread = $null
            if ($null -ne $venteMin -and $null -ne $achatMax) { $spread = Arrondir ($venteMin - $achatMax) }

            [void]$lignes.Add([ordered]@{
                hub              = [string]$h.nom
                hub_region       = $region
                hub_station      = $station
                mineral          = [string]$m.nom
                type_id          = $tid
                achat_max        = $achatMax
                achat_volume     = $achatVol
                achat_nb         = $achatNb
                vente_min        = $venteMin
                vente_volume     = $venteVol
                vente_nb         = $venteNb
                spread           = $spread
                prix_vente       = $prixVente
                prix_achat       = $prixAchat
                net_vente_instant= $netVenteInstant
                net_vente_posee  = $netVentePosee
                cout_achat       = $coutAchat
            })
        }
    }

    return [ordered]@{
        maj            = (Get-Date).ToString('o')
        maj_lisible    = (Get-Date).ToString('HH:mm:ss')
        source         = 'ESI (api publique EVE, lecture seule)'
        cache_secondes = [int]$script:Config.duree_cache_esi_s
        limiter_station = $limiterStation
        frais          = [ordered]@{
            courtage_pct    = [double]$script:Config.frais.courtage_pct
            taxe_vente_pct  = [double]$script:Config.frais.taxe_vente_pct
        }
        strategie      = [ordered]@{
            comportement    = [string]$script:Config.strategie.comportement
            pas_sous_cote   = $pas
        }
        hubs           = @($hubs | ForEach-Object { [ordered]@{ nom = $_.nom; region_id = $_.region_id; station_id = $_.station_id } })
        minerais       = @($minerais | ForEach-Object { [ordered]@{ nom = $_.nom; type_id = $_.type_id } })
        lignes         = @($lignes)
        erreurs        = @($erreurs)
    }
}

# =====================================================================
#  Reponses HTTP
# =====================================================================
$script:Mimes = @{
    '.html'='text/html; charset=utf-8'; '.htm'='text/html; charset=utf-8'
    '.css' ='text/css; charset=utf-8';  '.js' ='application/javascript; charset=utf-8'
    '.json'='application/json; charset=utf-8'; '.svg'='image/svg+xml'
    '.png' ='image/png'; '.jpg'='image/jpeg'; '.gif'='image/gif'
    '.ico' ='image/x-icon'; '.woff2'='font/woff2'; '.txt'='text/plain; charset=utf-8'
}

function Send-Json($ctx, $objet, [int]$code = 200) {
    $ctx.Response.StatusCode = $code
    $ctx.Response.ContentType = 'application/json; charset=utf-8'
    $json = $objet | ConvertTo-Json -Depth 12 -Compress
    if ($null -eq $json) { $json = 'null' }
    $octets = [Text.Encoding]::UTF8.GetBytes($json)
    $ctx.Response.OutputStream.Write($octets, 0, $octets.Length)
    $ctx.Response.Close()
}

function Send-Texte($ctx, [string]$texte, [int]$code = 200) {
    $ctx.Response.StatusCode = $code
    $ctx.Response.ContentType = 'text/plain; charset=utf-8'
    $octets = [Text.Encoding]::UTF8.GetBytes($texte)
    $ctx.Response.OutputStream.Write($octets, 0, $octets.Length)
    $ctx.Response.Close()
}

function Send-Fichier($ctx, [string]$relatif, [string]$Dossier) {
    if ([string]::IsNullOrWhiteSpace($Dossier)) { $Dossier = $AppDir }
    $relatif = $relatif.TrimStart('/','\')
    $relatif = [Uri]::UnescapeDataString($relatif)
    if ([string]::IsNullOrWhiteSpace($relatif)) { $relatif = 'index.html' }
    $complet = Join-Path $Dossier $relatif
    $racine  = [IO.Path]::GetFullPath($Dossier)
    $sep     = [IO.Path]::DirectorySeparatorChar

    $plein = [IO.Path]::GetFullPath($complet)
    if (-not $plein.StartsWith($racine + $sep, [StringComparison]::OrdinalIgnoreCase)) {
        Send-Texte $ctx 'interdit' 403; return
    }
    if (-not (Test-Path -LiteralPath $plein -PathType Leaf)) {
        Send-Texte $ctx ('fichier introuvable : ' + $relatif) 404; return
    }

    $ext = [IO.Path]::GetExtension($plein).ToLower()
    $mime = if ($script:Mimes.ContainsKey($ext)) { $script:Mimes[$ext] } else { 'application/octet-stream' }
    $octets = [IO.File]::ReadAllBytes($plein)
    $ctx.Response.StatusCode = 200
    $ctx.Response.ContentType = $mime
    $ctx.Response.ContentLength64 = $octets.Length
    $ctx.Response.OutputStream.Write($octets, 0, $octets.Length)
    $ctx.Response.Close()
}

function Read-Corps($req) {
    $lecteur = New-Object IO.StreamReader($req.InputStream, $req.ContentEncoding)
    try { return $lecteur.ReadToEnd() } finally { $lecteur.Dispose() }
}

# =====================================================================
#  Serveur
# =====================================================================
$listener = $null
$choisi = $null
$prefixeChoisi = $null
foreach ($p in $Port..($Port + 20)) {
    $tentatives = New-Object System.Collections.ArrayList
    if ($Reseau) { [void]$tentatives.Add("http://+:$p/") }
    [void]$tentatives.Add("http://localhost:$p/")
    foreach ($prefixe in $tentatives) {
        # un HttpListener neuf a chaque essai : apres un Start() refuse, l'objet
        # n'est plus reutilisable (sinon le repli localhost echouerait aussi).
        $essai = New-Object System.Net.HttpListener
        try {
            $essai.Prefixes.Add($prefixe)
            $essai.Start()
            $listener = $essai
            $choisi = $p
            $prefixeChoisi = $prefixe
            break
        } catch {
            try { $essai.Close() } catch { }
        }
    }
    if ($choisi) { break }
}

if (-not $choisi) {
    Write-Host ""
    Write-Host " Impossible d'ouvrir un port local entre $Port et $($Port + 20)." -ForegroundColor Red
    if ($Reseau) {
        Write-Host " Le mode reseau (-Reseau) demande les droits administrateur." -ForegroundColor Yellow
        Write-Host " Relance ce fichier en tant qu'administrateur, ou autorise le port une fois :"
        Write-Host "   netsh http add urlacl url=http://+:$Port/ user=%USERDOMAIN%\%USERNAME%"
    }
    Write-Host " Ferme une autre fenetre de l'app puis relance."
    Read-Host " Appuie sur Entree pour fermer"
    exit 1
}

$enReseau = $prefixeChoisi -like 'http://+*'
$url = "http://localhost:$choisi/"
Write-Host ""
Write-Host "  EVE - Prix des minerais" -ForegroundColor Green
Write-Host "  ------------------------------------------------"
Write-Host "  Application :  $url"
Write-Host "  Version mobile:  $($url)mobile/" -ForegroundColor Cyan
if ($enReseau) {
    Write-Host "  Reseau local (telephone sur le meme Wi-Fi) :" -ForegroundColor Cyan
    try {
        $ips = [System.Net.Dns]::GetHostAddresses([System.Net.Dns]::GetHostName()) |
               Where-Object { $_.AddressFamily -eq 'InterNetwork' -and $_.IPAddressToString -ne '127.0.0.1' } |
               Select-Object -ExpandProperty IPAddressToString -Unique
        foreach ($ip in $ips) {
            Write-Host "     http://$ip`:$choisi/mobile/"
        }
        if (-not $ips) { Write-Host "     (aucune adresse IPv4 detectee)" -ForegroundColor Yellow }
    } catch { }
    Write-Host "  (autorise l'app dans le pare-feu Windows si demande)" -ForegroundColor DarkGray
} else {
    if ($Reseau) {
        Write-Host "  Mode reseau indisponible (droits admin manquants ?), reste en local." -ForegroundColor Yellow
    }
    Write-Host "  Astuce mobile : relance avec  -Reseau  puis ouvre l'adresse ci-dessus" -ForegroundColor DarkGray
    Write-Host "                  depuis le telephone (meme Wi-Fi)." -ForegroundColor DarkGray
}
Write-Host "  Source      :  API publique ESI (lecture seule)"
Write-Host "  Arret       :  ferme cette fenetre, ou Ctrl+C"
Write-Host ""

if (-not $NePasOuvrir) { Start-Process $url | Out-Null }

try {
    while ($listener.IsListening) {
        $ctx = $null
        try { $ctx = $listener.GetContext() } catch { break }
        if ($null -eq $ctx) { break }

        $req    = $ctx.Request
        $chemin = $req.Url.AbsolutePath
        $query  = $req.Url.Query

        try {
            if ($chemin -eq '/api/ping') {
                Send-Json $ctx @{ ok = $true; app = 'eve-prix-minerais'; source = 'ESI' }
            }
            elseif ($chemin -eq '/api/config') {
                if ($req.HttpMethod -eq 'POST') {
                    $corps = Read-Corps $req
                    $nouveau = $null
                    try { $nouveau = $corps | ConvertFrom-Json } catch { }
                    if ($null -eq $nouveau) {
                        Send-Json $ctx @{ ok = $false; erreur = 'JSON invalide' } 400
                    } else {
                        Sauver-Config $nouveau
                        $script:Config = Get-Config
                        $script:CacheEsi = @{}
                        Send-Json $ctx @{ ok = $true }
                    }
                }
                else {
                    Send-Json $ctx $script:Config
                }
            }
            elseif ($chemin -eq '/api/marche') {
                $force = ($query -match 'force=1')
                $donnees = Get-Marche -Force:$force
                Send-Json $ctx $donnees
            }
            elseif ($chemin -eq '/api/resoudre') {
                $nom = $null
                if ($query -match 'nom=([^&]+)') { $nom = [Uri]::UnescapeDataString($matches[1]) }
                if ([string]::IsNullOrWhiteSpace($nom)) {
                    Send-Json $ctx @{ ok = $false; erreur = 'parametre nom manquant' } 400
                } else {
                    $tid = Resoudre-TypeId $nom
                    if ($tid -gt 0) { Send-Json $ctx @{ ok = $true; nom = $nom; type_id = $tid } }
                    else            { Send-Json $ctx @{ ok = $false; erreur = "type introuvable : $nom" } 404 }
                }
            }
            elseif ($chemin -eq '/mobile' -or $chemin -like '/mobile/*') {
                $rel = $chemin.Substring('/mobile'.Length)
                Send-Fichier $ctx $rel $MobileDir
            }
            elseif ($req.HttpMethod -eq 'GET') {
                Send-Fichier $ctx $chemin
            }
            else {
                Send-Texte $ctx 'action inconnue' 404
            }
        }
        catch {
            try { Send-Json $ctx @{ ok = $false; erreur = $_.Exception.Message } 500 } catch { }
        }
    }
}
finally {
    try { $listener.Stop(); $listener.Close() } catch { }
    Write-Host ""
    Write-Host "  Serveur arrete." -ForegroundColor DarkGray
}
